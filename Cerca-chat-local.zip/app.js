// ---------------------------------------------
// Cerca — buscador de lugares por GPS (OSM/Overpass)
// ---------------------------------------------

const OVERPASS_ENDPOINTS = [
  "https://overpass-api.de/api/interpreter",
  "https://overpass.private.coffee/api/interpreter",
  "https://lz4.overpass-api.de/api/interpreter",
  "https://overpass.kumi.systems/api/interpreter",
];

// Cada categoría define uno o más filtros Overpass (clave/valor exactos
// o expresiones regulares sobre "cuisine") y metadata visual.
const CATEGORY_DEFS = {
  bar: {
    label: "Bar",
    icon: "🍸",
    badgeClass: "bar",
    filters: [`nwr["amenity"="bar"](around:RADIUS,LAT,LON);`, `nwr["amenity"="pub"](around:RADIUS,LAT,LON);`],
  },
  cafe: {
    label: "Café",
    icon: "☕",
    badgeClass: "cafe",
    filters: [`nwr["amenity"="cafe"](around:RADIUS,LAT,LON);`],
  },
  parrilla: {
    label: "Parrilla",
    icon: "🔥",
    badgeClass: "parrilla",
    filters: [
      `nwr["amenity"="restaurant"]["cuisine"~"steak_house|barbecue|grill|argentin", i](around:RADIUS,LAT,LON);`,
    ],
  },
  restaurante: {
    label: "Restaurante",
    icon: "🍽",
    badgeClass: "restaurante",
    filters: [`nwr["amenity"="restaurant"](around:RADIUS,LAT,LON);`],
  },
  pizza: {
    label: "Pizza",
    icon: "🍕",
    badgeClass: "pizza",
    filters: [
      `nwr["amenity"~"restaurant|fast_food"]["cuisine"~"pizza", i](around:RADIUS,LAT,LON);`,
    ],
  },
  heladeria: {
    label: "Heladería",
    icon: "🍦",
    badgeClass: "heladeria",
    filters: [`nwr["amenity"="ice_cream"](around:RADIUS,LAT,LON);`],
  },
  panaderia: {
    label: "Panadería",
    icon: "🥐",
    badgeClass: "panaderia",
    filters: [`nwr["shop"="bakery"](around:RADIUS,LAT,LON);`],
  },
  farmacia: {
    label: "Farmacia",
    icon: "💊",
    badgeClass: "farmacia",
    filters: [`nwr["amenity"="pharmacy"](around:RADIUS,LAT,LON);`],
  },
  supermercado: {
    label: "Súper",
    icon: "🛒",
    badgeClass: "supermercado",
    filters: [
      `nwr["shop"="supermarket"](around:RADIUS,LAT,LON);`,
      `nwr["shop"="convenience"](around:RADIUS,LAT,LON);`,
    ],
  },
  comida_rapida: {
    label: "Rápida",
    icon: "🍔",
    badgeClass: "comida_rapida",
    filters: [`nwr["amenity"="fast_food"](around:RADIUS,LAT,LON);`],
  },
  estacion_servicio: {
    label: "Estación",
    icon: "⛽",
    badgeClass: "estacion_servicio",
    filters: [`nwr["amenity"="fuel"](around:RADIUS,LAT,LON);`],
  },
  kiosco: {
    label: "Kiosco",
    icon: "🏪",
    badgeClass: "kiosco",
    filters: [`nwr["shop"="kiosk"](around:RADIUS,LAT,LON);`, `nwr["shop"="convenience"]["name"](around:RADIUS,LAT,LON);`],
  },
};

// Nota: OSM no distingue "farmacia de turno" (guardia) — ese dato no está
// mapeado de forma estándar en ningún país, así que no se puede filtrar
// automáticamente. Mostramos todas las farmacias; el usuario puede fijarse
// el cartel de turno en el lugar.

// Combos de categorías: atajos para no tener que tildar siempre las mismas
// categorías. A diferencia de las "búsquedas favoritas", no fijan ubicación
// ni radio — solo aplican una selección de categorías en Inicio.
const DEFAULT_COMBOS = [
  { id: "previa", name: "Previa", icon: "🍻", cats: ["bar", "kiosco"] },
  { id: "domingo_familia", name: "Domingo con la familia", icon: "👨‍👩‍👧", cats: ["heladeria", "parrilla"] },
];

const HISTORY_KEY = "cerca_history_v1";
const DARK_KEY = "cerca_dark_v1";
const FAVORITES_KEY = "cerca_favorites_v1";
const NOTES_KEY = "cerca_notes_v1";
const SAVED_SEARCHES_KEY = "cerca_saved_searches_v1";
const SETTINGS_KEY = "cerca_settings_v1";
const CAR_KEY = "cerca_car_v1";
const SUGGESTION_KEY = "cerca_suggestion_v1";
const ZONE_CACHE_KEY = "cerca_zone_cache_v1";
const LAST_RESULT_KEY = "cerca_last_result_v1";
const ONBOARDING_KEY = "cerca_onboarding_seen_v1";
const HIDDEN_PLACES_KEY = "cerca_hidden_places_v1";
const COMBOS_KEY = "cerca_combos_v1";
const INSTALL_DISMISSED_KEY = "cerca_install_dismissed_v1";

// Todas las claves de localStorage que usa la app — se usan para el borrado
// total de datos desde el Menú. Si agregás una clave nueva, sumala acá.
const ALL_STORAGE_KEYS = [
  HISTORY_KEY, DARK_KEY, FAVORITES_KEY, NOTES_KEY, SAVED_SEARCHES_KEY,
  SETTINGS_KEY, CAR_KEY, SUGGESTION_KEY, ZONE_CACHE_KEY, LAST_RESULT_KEY,
  ONBOARDING_KEY, HIDDEN_PLACES_KEY, COMBOS_KEY, INSTALL_DISMISSED_KEY,
];
const HISTORY_LIMIT = 30;
const ZONE_CACHE_TTL_MS = 8 * 60 * 1000; // 8 minutos: evita repegarle a Overpass en la misma zona
const ZONE_CACHE_MAX_ENTRIES = 15;
const LOW_RESULTS_THRESHOLD = 3;
const RESULTS_PAGE_SIZE = 24; // cuántas tarjetas se renderizan por tanda

const ACCENTS = {
  amber:  { accent: "#F5A623", glow: "rgba(245,166,35,0.35)", dim: "rgba(245,166,35,0.15)", border: "rgba(245,166,35,0.28)", glass: "rgba(245,166,35,0.6)" },
  blue:   { accent: "#0A84FF", glow: "rgba(10,132,255,0.35)",  dim: "rgba(10,132,255,0.15)",  border: "rgba(10,132,255,0.28)", glass: "rgba(10,132,255,0.6)" },
  pink:   { accent: "#FF4D7E", glow: "rgba(255,77,126,0.35)",  dim: "rgba(255,77,126,0.15)",  border: "rgba(255,77,126,0.28)", glass: "rgba(255,77,126,0.6)" },
  green:  { accent: "#3DD68C", glow: "rgba(61,214,140,0.35)",  dim: "rgba(61,214,140,0.15)",  border: "rgba(61,214,140,0.28)", glass: "rgba(61,214,140,0.6)" },
  purple: { accent: "#C778DD", glow: "rgba(199,120,221,0.35)", dim: "rgba(199,120,221,0.15)", border: "rgba(199,120,221,0.28)", glass: "rgba(199,120,221,0.6)" },
  teal:   { accent: "#38C4E0", glow: "rgba(56,196,224,0.35)",  dim: "rgba(56,196,224,0.15)",  border: "rgba(56,196,224,0.28)", glass: "rgba(56,196,224,0.6)" },
};

const state = {
  selected: new Set(),
  radius: 1000,
  userLat: null,
  userLon: null,
  results: [],
  filteredResults: [],
  view: "list",
  map: null,
  markersLayer: null,
  clusterLayer: null,
  mapaMap: null,
  mapaMarkersLayer: null,
  activeTab: "inicio",
  history: [],
  favorites: [],
  notes: {},
  savedSearches: [],
  settings: { defaultRadius: null, defaultCats: null, accent: "amber", sortBy: "dist", openNowOnly: false, wheelchairOnly: false },
  searchText: "",
  car: null,
  mapCatFilter: new Set(),
  hiddenPlaces: new Set(),
  lastQuery: null,
  lastSearchWasCache: false,
  lastSearchWasOffline: false,
  compareMode: false,
  compareSelection: [],
  dataSaver: false,
  combos: [],
};

const els = {
  chips: document.getElementById("categoryChips"),
  radius: document.getElementById("radius"),
  radiusValue: document.getElementById("radiusValue"),
  searchBtn: document.getElementById("searchBtn"),
  searchBtnLabel: document.getElementById("searchBtnLabel"),
  statusBox: document.getElementById("statusBox"),
  viewToggle: document.getElementById("viewToggle"),
  viewToggleThumb: document.getElementById("viewToggleThumb"),
  resultsView: document.getElementById("resultsView"),
  mapView: document.getElementById("mapView"),

  dock: document.getElementById("dock"),
  dockThumb: document.getElementById("dockThumb"),
  historyBadge: document.getElementById("historyBadge"),
  favBadge: document.getElementById("favBadgeMenu"),
  viewInicio: document.getElementById("view-inicio"),
  viewBusquedas: document.getElementById("view-busquedas"),
  viewMapa: document.getElementById("view-mapa"),
  mapaStatus: document.getElementById("mapaStatus"),
  viewFavoritos: document.getElementById("view-favoritos"),
  viewMenu: document.getElementById("view-menu"),
  menuFavoritos: document.getElementById("menuFavoritos"),
  historyList: document.getElementById("historyList"),
  savedSearchesList: document.getElementById("savedSearchesList"),
  savedSearchesTitle: document.getElementById("savedSearchesTitle"),
  favoritesList: document.getElementById("favoritesList"),
  compareToggleBtn: document.getElementById("compareToggleBtn"),
  compareBarBtn: document.getElementById("compareBarBtn"),
  compareCount: document.getElementById("compareCount"),
  compareOverlay: document.getElementById("compareOverlay"),
  compareSheet: document.getElementById("compareSheet"),
  compareClose: document.getElementById("compareClose"),
  compareContent: document.getElementById("compareContent"),

  suggestionBtn: document.getElementById("suggestionBtn"),
  suggestionSub: document.getElementById("suggestionSub"),

  resultsToolbar: document.getElementById("resultsToolbar"),
  resultsStatus: document.getElementById("resultsStatus"),
  refreshResultsBtn: document.getElementById("refreshResultsBtn"),
  busquedasIntro: document.getElementById("busquedasIntro"),
  searchText: document.getElementById("searchText"),
  sortSelect: document.getElementById("sortSelect"),
  openNowToggle: document.getElementById("openNowToggle"),
  wheelchairToggle: document.getElementById("wheelchairToggle"),
  mapCatFilter: document.getElementById("mapCatFilter"),
  combosRow: document.getElementById("combosRow"),
  comboAddBtn: document.getElementById("comboAddBtn"),

  menuClearHistory: document.getElementById("menuClearHistory"),
  menuRestoreReported: document.getElementById("menuRestoreReported"),
  menuEraseAll: document.getElementById("menuEraseAll"),
  menuShareWhatsapp: document.getElementById("menuShareWhatsapp"),
  menuCopyLink: document.getElementById("menuCopyLink"),
  menuExportFavorites: document.getElementById("menuExportFavorites"),
  menuImportFavorites: document.getElementById("menuImportFavorites"),
  importFavoritesInput: document.getElementById("importFavoritesInput"),
  menuCar: document.getElementById("menuCar"),
  menuCarTitle: document.getElementById("menuCarTitle"),
  menuCarDesc: document.getElementById("menuCarDesc"),
  menuDarkMode: document.getElementById("menuDarkMode"),
  darkModeToggle: document.getElementById("darkModeToggle"),
  menuAbout: document.getElementById("menuAbout"),
  aboutOverlay: document.getElementById("aboutOverlay"),
  aboutClose: document.getElementById("aboutClose"),
  onboardingOverlay: document.getElementById("onboardingOverlay"),
  onboardingClose: document.getElementById("onboardingClose"),
  accentSwatches: document.getElementById("accentSwatches"),
  toast: document.getElementById("toast"),

  sheetOverlay: document.getElementById("placeSheetOverlay"),
  sheet: document.getElementById("placeSheet"),
  sheetClose: document.getElementById("sheetClose"),
  sheetContent: document.getElementById("sheetContent"),

  installBanner: document.getElementById("installBanner"),
  installBannerBtn: document.getElementById("installBannerBtn"),
  installBannerClose: document.getElementById("installBannerClose"),
};

// ---------- UI: thumb deslizante de vidrio (dock / view-toggle) ----------
function slideGlassThumb(container, thumb, activeBtn) {
  if (!container || !thumb || !activeBtn) return;
  const cRect = container.getBoundingClientRect();
  const bRect = activeBtn.getBoundingClientRect();
  const x = bRect.left - cRect.left;
  thumb.style.width = `${bRect.width}px`;
  thumb.style.transform = `translateX(${x}px)`;
}
window.addEventListener("resize", () => {
  const activeDock = els.dock.querySelector(".dock-item.active");
  if (activeDock) slideGlassThumb(els.dock, els.dockThumb, activeDock);
  const activeToggle = els.viewToggle.querySelector(".toggle-btn.active");
  if (activeToggle && !els.viewToggle.hidden) slideGlassThumb(els.viewToggle, els.viewToggleThumb, activeToggle);
});

// ---------- UI: tarjetas de categoría ----------
els.chips.addEventListener("click", (e) => {
  const card = e.target.closest(".cat-card");
  if (!card) return;
  const cat = card.dataset.cat;
  if (state.selected.has(cat)) {
    state.selected.delete(cat);
    card.classList.remove("selected");
  } else {
    state.selected.add(cat);
    card.classList.add("selected");
  }
  card.setAttribute("aria-pressed", String(state.selected.has(cat)));
  renderCombos();
});

// ---------- UI: dock inferior ----------
els.dock.addEventListener("click", (e) => {
  const btn = e.target.closest(".dock-item");
  if (!btn) return;
  switchTab(btn.dataset.view);
});

function switchTab(tab) {
  state.activeTab = tab;
  document.querySelectorAll(".dock-item").forEach((b) => {
    const isActive = b.dataset.view === tab;
    b.classList.toggle("active", isActive);
    if (isActive) b.setAttribute("aria-current", "page");
    else b.removeAttribute("aria-current");
  });
  const activeDock = els.dock.querySelector(".dock-item.active");
  slideGlassThumb(els.dock, els.dockThumb, activeDock);
  els.viewInicio.hidden = tab !== "inicio";
  els.viewBusquedas.hidden = tab !== "busquedas";
  els.viewMapa.hidden = tab !== "mapa";
  els.viewFavoritos.hidden = tab !== "favoritos";
  els.viewMenu.hidden = tab !== "menu";

  if (tab === "busquedas") { renderHistory(); renderSavedSearches(); }
  if (tab === "mapa") renderMapaTab();
  if (tab === "favoritos") renderFavorites();
  if (tab === "inicio" && state.view === "map") {
    setTimeout(() => state.map && state.map.invalidateSize(), 50);
  }
  if (tab === "busquedas" && document.getElementById("foundCtaBtn")) {
    setStatus("");
  }
}

if (els.menuFavoritos) {
  els.menuFavoritos.addEventListener("click", () => switchTab("favoritos"));
}

// ---------- UI: radio de búsqueda ----------
els.radius.addEventListener("input", () => {
  state.radius = parseInt(els.radius.value, 10);
  els.radiusValue.textContent = formatDistance(state.radius, true);
});
els.radiusValue.textContent = formatDistance(state.radius, true);

// ---------- UI: toggle lista/mapa ----------
els.viewToggle.addEventListener("click", (e) => {
  const btn = e.target.closest(".toggle-btn");
  if (!btn) return;
  setView(btn.dataset.view);
});

function setView(view) {
  state.view = view;
  document.querySelectorAll(".toggle-btn").forEach((b) => {
    const isActive = b.dataset.view === view;
    b.classList.toggle("active", isActive);
    b.setAttribute("aria-pressed", String(isActive));
  });
  const activeToggle = els.viewToggle.querySelector(".toggle-btn.active");
  slideGlassThumb(els.viewToggle, els.viewToggleThumb, activeToggle);
  els.resultsView.hidden = view !== "list";
  els.mapView.hidden = view !== "map";
  const shown = view === "list" ? els.resultsView : els.mapView;
  shown.classList.remove("view-fade-in");
  void shown.offsetWidth;
  shown.classList.add("view-fade-in");
  if (view === "map") {
    initMapIfNeeded();
    setTimeout(() => state.map && state.map.invalidateSize(), 50);
  }
}

// ---------- Buscar ----------
els.searchBtn.addEventListener("click", () => runSearch());

async function runSearch(overrides) {
  const forceRefresh = !!(overrides && overrides.forceRefresh);
  if (overrides && Array.isArray(overrides.cats)) {
    state.selected = new Set(overrides.cats || []);
    state.radius = overrides.radius || state.radius;
    els.radius.value = state.radius;
    els.radiusValue.textContent = formatDistance(state.radius, true);
    document.querySelectorAll(".cat-card").forEach((card) => {
      const isSel = state.selected.has(card.dataset.cat);
      card.classList.toggle("selected", isSel);
      card.setAttribute("aria-pressed", String(isSel));
    });
    renderCombos();
  }
  setStatus("");
  els.searchBtn.disabled = true;
  els.searchBtn.classList.add("loading");
  els.searchBtnLabel.textContent = "Ubicándote…";
  showRadarStatus();

  try {
    // Si el usuario eligió una dirección manual, la usamos; si no, GPS
    let pos;
    if (addrState.lat !== null && addrState.lon !== null) {
      state.userLat = addrState.lat;
      state.userLon = addrState.lon;
    } else {
      pos = await getPosition();
      state.userLat = pos.coords.latitude;
      state.userLon = pos.coords.longitude;
    }

    els.searchBtnLabel.textContent = "Buscando lugares…";

    const cats = state.selected.size > 0 ? [...state.selected] : Object.keys(CATEGORY_DEFS);
    state.lastQuery = { cats, radius: state.radius };
    state.lastSearchWasCache = false;
    state.lastSearchWasOffline = false;

    const cacheKey = zoneCacheKey(state.userLat, state.userLon, state.radius, cats);
    const cached = forceRefresh ? null : getZoneCacheEntry(cacheKey);

    let elements;
    if (cached) {
      elements = cached.elements;
      state.lastSearchWasCache = true;
    } else {
      showResultsSkeleton();
      setStatus("Consultando OpenStreetMap…");
      try {
        elements = await queryOverpass(cats, state.userLat, state.userLon, state.radius);
        setZoneCacheEntry(cacheKey, elements);
        saveLastResult({ cats, radius: state.radius, lat: state.userLat, lon: state.userLon, elements });
      } catch (err) {
        const fallback = loadLastResult();
        if (fallback && (!navigator.onLine || err.message === "overpass-failed")) {
          elements = fallback.elements;
          state.lastSearchWasOffline = true;
        } else {
          throw err;
        }
      }
    }

    state.results = buildResults(elements, cats);
    state.mapCatFilter = new Set(cats);
    state.renderedCount = RESULTS_PAGE_SIZE;
    if (els.searchText) els.searchText.value = "";
    state.searchText = "";
    renderResults();

    if (state.lastSearchWasCache) {
      setStatus("Resultados desde caché (misma zona hace poco, no volvimos a consultar OSM)", "cached");
      els.refreshResultsBtn.hidden = false;
    } else if (state.lastSearchWasOffline) {
      setStatus("Sin conexión: te mostramos tu última búsqueda guardada", "offline");
      els.refreshResultsBtn.hidden = false;
    } else if (state.results.length > 0) {
      showFoundStatus(state.results.length);
      els.refreshResultsBtn.hidden = true;
      maybeShowInstallBanner();
    } else {
      setStatus("");
      els.refreshResultsBtn.hidden = true;
    }

    state.settings.defaultRadius = state.radius;
    state.settings.defaultCats = cats;
    saveSettings();

    addHistoryEntry({
      ts: Date.now(),
      cats,
      radius: state.radius,
      count: state.results.length,
      lat: state.userLat,
      lon: state.userLon,
    });
  } catch (err) {
    console.error(err);
    setStatus(errorMessage(err), "error");
    showToast(errorMessage(err));
    if (!els.resultsView.hidden && els.resultsView.querySelector(".skeleton-card")) {
      els.resultsView.innerHTML = `<div class="empty-state">${escapeHtml(errorMessage(err))}</div>`;
    }
  } finally {
    els.searchBtn.disabled = false;
    els.searchBtn.classList.remove("loading");
    els.searchBtnLabel.textContent = "Buscar cerca mío";
  }
}

// ---------- Skeleton loader mientras esperamos Overpass ----------
function showResultsSkeleton(count = 6) {
  els.viewToggle.hidden = true;
  els.resultsToolbar.hidden = true;
  els.resultsStatus.hidden = true;
  if (els.busquedasIntro) els.busquedasIntro.hidden = true;
  els.mapView.hidden = true;
  els.resultsView.hidden = false;
  els.resultsView.innerHTML = Array.from({ length: count })
    .map(
      () => `
        <div class="place-card skeleton-card" aria-hidden="true">
          <div class="place-thumb skeleton-block"></div>
          <div class="place-info">
            <div class="skeleton-line skeleton-line-title"></div>
            <div class="skeleton-line skeleton-line-sub"></div>
          </div>
        </div>
      `
    )
    .join("");
}

function errorMessage(err) {
  if (err && err.code === 1) return "Le negaste el permiso de ubicación al navegador. Para buscar cerca tuyo, activalo desde los ajustes del sitio (ícono de candado o 🛈 junto a la URL) y volvé a intentar.";
  if (err && err.code === 2) return "El GPS no pudo determinar tu posición. Probá salir a un lugar más despejado o revisá que la ubicación esté activada en el celular.";
  if (err && err.code === 3) return "Se agotó el tiempo esperando el GPS. Probá de nuevo con mejor señal.";
  if (err && err.message === "no-geolocation") return "Este navegador no soporta geolocalización, o la página no se está sirviendo por HTTPS.";
  if (err && err.message === "overpass-failed") return "No pudimos consultar OpenStreetMap. Probá de nuevo en un momento.";
  return "Algo falló buscando lugares cerca tuyo. Probá de nuevo.";
}

function getPosition() {
  return new Promise((resolve, reject) => {
    if (!("geolocation" in navigator)) {
      reject(new Error("no-geolocation"));
      return;
    }
    // Timeout de respaldo: en algunas PWA instaladas (sobre todo iOS) el
    // navegador a veces no dispara ni el callback ni su propio "timeout"
    // nativo, y el botón queda girando para siempre. Este watchdog garantiza
    // que la búsqueda siempre termine, con error, a los 14s como máximo.
    let settled = false;
    const watchdog = setTimeout(() => {
      if (settled) return;
      settled = true;
      const err = new Error("gps-timeout");
      err.code = 3;
      reject(err);
    }, 14000);

    navigator.geolocation.getCurrentPosition(
      (pos) => {
        if (settled) return;
        settled = true;
        clearTimeout(watchdog);
        resolve(pos);
      },
      (err) => {
        if (settled) return;
        settled = true;
        clearTimeout(watchdog);
        reject(err);
      },
      { enableHighAccuracy: true, timeout: 12000, maximumAge: 60000 }
    );
  });
}

function showRadarStatus() {
  if (els.suggestionBtn) els.suggestionBtn.hidden = false;
  els.statusBox.innerHTML = `
    <div class="locate-anim" aria-hidden="true">
      <div class="locate-ring"></div>
      <div class="locate-ring"></div>
      <div class="locate-ring"></div>
      <div class="locate-orbit"></div>
      <div class="locate-satellite"></div>
      <div class="locate-core"></div>
    </div>
    <div class="locate-label">Buscando tu ubicación…</div>
  `;
}

function positionFoundCta() {
  const wrap = document.getElementById("foundCtaWrap");
  if (!wrap) { window.removeEventListener("resize", positionFoundCta); return; }
  const target = els.dock.querySelector('[data-view="busquedas"]');
  if (!target) return;
  const rect = target.getBoundingClientRect();
  wrap.style.left = `${rect.left + rect.width / 2}px`;
  wrap.style.top = `${rect.top - 10}px`;
}

function showFoundStatus(count) {
  els.statusBox.classList.remove("error", "cached", "offline");
  if (els.suggestionBtn) els.suggestionBtn.hidden = true;
  els.statusBox.innerHTML = `
    <div class="found-cta-wrap" id="foundCtaWrap">
      <button type="button" class="found-cta" id="foundCtaBtn">
        <span class="found-cta-text"><span class="found-cta-emoji" aria-hidden="true">📍</span> ${count} lugar${count === 1 ? "" : "es"} encontrado${count === 1 ? "" : "s"}. ¡Mirá los resultados en <strong>Búsquedas</strong>!</span>
        <span class="found-cta-arrow" aria-hidden="true">👇</span>
      </button>
    </div>
  `;
  const btn = document.getElementById("foundCtaBtn");
  if (btn) btn.addEventListener("click", () => switchTab("busquedas"));
  positionFoundCta();
  window.removeEventListener("resize", positionFoundCta);
  window.addEventListener("resize", positionFoundCta);
}

function setStatus(msg, variant) {
  els.statusBox.classList.remove("error", "cached", "offline");
  if (els.suggestionBtn) els.suggestionBtn.hidden = false;
  if (variant) els.statusBox.classList.add(variant);
  if (variant === "cached") {
    els.statusBox.innerHTML = `<span aria-hidden="true">⚡</span><span>${escapeHtml(msg)}</span>`;
  } else if (variant === "offline") {
    els.statusBox.innerHTML = `<span aria-hidden="true">📴</span><span>${escapeHtml(msg)}</span>`;
  } else if (variant === "error") {
    els.statusBox.innerHTML = msg ? `<span aria-hidden="true">⚠️</span><span>${escapeHtml(msg)}</span>` : "";
  } else {
    els.statusBox.textContent = msg;
  }
}

// ---------- Caché de resultados por zona ----------
// Evita repegarle a Overpass si el usuario busca dos veces en la misma zona
// (mismo radio/categorías) en poco tiempo. También guardamos el último
// resultado exitoso "a secas" para poder mostrar algo si no hay conexión.
function roundCoord(v) {
  // ~110m de grilla: suficiente para considerar "la misma zona"
  return Math.round(v * 1000) / 1000;
}

function zoneCacheKey(lat, lon, radius, cats) {
  return `${roundCoord(lat)},${roundCoord(lon)}|${radius}|${[...cats].sort().join(",")}`;
}

function loadZoneCache() {
  try {
    const raw = localStorage.getItem(ZONE_CACHE_KEY);
    return raw ? JSON.parse(raw) : {};
  } catch (e) { return {}; }
}

function saveZoneCacheMap(cache) {
  try { localStorage.setItem(ZONE_CACHE_KEY, JSON.stringify(cache)); } catch (e) {}
}

function getZoneCacheEntry(key) {
  const cache = loadZoneCache();
  const entry = cache[key];
  if (!entry) return null;
  if (Date.now() - entry.ts > ZONE_CACHE_TTL_MS) return null;
  return entry;
}

function setZoneCacheEntry(key, elements) {
  const cache = loadZoneCache();
  cache[key] = { ts: Date.now(), elements };
  const keys = Object.keys(cache);
  if (keys.length > ZONE_CACHE_MAX_ENTRIES) {
    keys.sort((a, b) => cache[a].ts - cache[b].ts);
    delete cache[keys[0]];
  }
  saveZoneCacheMap(cache);
}

function saveLastResult(payload) {
  try {
    localStorage.setItem(LAST_RESULT_KEY, JSON.stringify({ ...payload, ts: Date.now() }));
  } catch (e) {}
}

function loadLastResult() {
  try {
    const raw = localStorage.getItem(LAST_RESULT_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch (e) { return null; }
}

// ---------- Overpass query ----------
async function queryOverpass(cats, lat, lon, radius) {
  const filterLines = [];
  cats.forEach((cat) => {
    const def = CATEGORY_DEFS[cat];
    if (!def) return;
    def.filters.forEach((f) => {
      filterLines.push(
        f.replace("RADIUS", radius).replace("LAT", lat).replace("LON", lon)
      );
    });
  });

  const query = `[out:json][timeout:25];(${filterLines.join("")});out center tags;`;

  // Consultamos todos los espejos de Overpass en paralelo y nos quedamos con
  // el primero que responda bien (Promise.any), en vez de ir secuencial:
  // así no dependemos de que el primer endpoint de la lista esté saturado.
  // Cada fetch tiene su propio timeout (AbortController): sin esto, si la red
  // se cuelga sin responder ni fallar, la promesa nunca se resuelve y el botón
  // de búsqueda queda girando para siempre.
  const FETCH_TIMEOUT_MS = 15000;
  const attempts = OVERPASS_ENDPOINTS.map((endpoint) => {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), FETCH_TIMEOUT_MS);
    return fetch(endpoint, {
      method: "POST",
      body: "data=" + encodeURIComponent(query),
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
        // Algunos espejos de Overpass (overpass-api.de) empezaron a devolver
        // 406 Not Acceptable a pedidos sin este header explícito.
        "Accept": "application/json",
      },
      signal: controller.signal,
    })
      .then((res) => {
        if (!res.ok) throw new Error(`bad-status-${res.status}`);
        return res.json();
      })
      .then((json) => json.elements || [])
      .catch((err) => {
        // Promise.any solo expone un AggregateError genérico; logueamos acá
        // el motivo real de cada espejo para poder diagnosticar en consola.
        console.warn(`Overpass falló en ${endpoint}:`, err && err.message ? err.message : err);
        throw err;
      })
      .finally(() => clearTimeout(timer));
  });

  try {
    return await Promise.any(attempts);
  } catch (e) {
    throw new Error("overpass-failed");
  }
}

// ---------- Resolver nombre de un lugar ----------
// Prioridad: name > alt_name > brand > nombre de operador > etiqueta de categoría
function resolveName(tags, category) {
  if (tags.name) return tags.name;
  if (tags.alt_name) return tags.alt_name;
  if (tags.brand) return tags.brand;
  if (tags.operator) return tags.operator;
  // Último recurso: etiqueta legible de la categoría
  const def = CATEGORY_DEFS[category];
  return def ? def.label : "Lugar sin nombre";
}

// ---------- Procesar resultados ----------
function buildResults(elements, cats) {
  const items = [];
  const seen = new Set();

  elements.forEach((el) => {
    const lat = el.lat ?? el.center?.lat;
    const lon = el.lon ?? el.center?.lon;
    if (lat == null || lon == null) return;

    const key = `${el.id}`;
    if (seen.has(key)) return;
    seen.add(key);

    const tags = el.tags || {};
    if (state.hiddenPlaces.has(key)) return;
    const name = resolveName(tags, classify(tags, cats));
    const category = classify(tags, cats);
    const dist = haversine(state.userLat, state.userLon, lat, lon);

    items.push({
      id: el.id,
      name,
      lat,
      lon,
      dist,
      category,
      address: buildAddress(tags),
      contact: buildContact(tags),
      rating: buildRating(tags),
      wheelchair: tags.wheelchair || "",
    });
  });

  items.sort((a, b) => a.dist - b.dist);
  return items;
}

// Extrae teléfono, web, redes, horario y foto (si están mapeados en OSM)
function buildContact(tags) {
  const phone = tags.phone || tags["contact:phone"] || tags["contact:mobile"] || "";
  const website = tags.website || tags["contact:website"] || tags.url || "";
  const email = tags.email || tags["contact:email"] || "";
  const instagram = normalizeSocial(tags.instagram || tags["contact:instagram"], "instagram.com");
  const facebook = normalizeSocial(tags.facebook || tags["contact:facebook"], "facebook.com");
  const opening = tags.opening_hours || "";
  const photo = photoUrl(tags);
  return { phone, website, email, instagram, facebook, opening, photo };
}

// Acepta tanto usuarios sueltos ("@lugar") como URLs completas y devuelve
// siempre una URL absoluta a la red social.
function normalizeSocial(value, domain) {
  if (!value) return "";
  if (/^https?:\/\//i.test(value)) return value;
  const handle = value.replace(/^@/, "").trim();
  if (!handle) return "";
  return `https://${domain}/${handle}`;
}

// Foto real del lugar vía Wikimedia Commons (licencia libre) si está
// mapeada en OSM (tag "image" o "wikimedia_commons"). Sin esto, no hay foto.
function photoUrl(tags) {
  if (tags.image && /^https?:\/\//i.test(tags.image)) return tags.image;
  if (tags.wikimedia_commons) {
    const name = tags.wikimedia_commons.replace(/^File:/i, "");
    return `https://commons.wikimedia.org/wiki/Special:FilePath/${encodeURIComponent(name)}?width=640`;
  }
  return "";
}

function classify(tags, cats) {
  const cuisine = (tags.cuisine || "").toLowerCase();
  const amenity = tags.amenity;
  const shop = tags.shop;

  if (cats.includes("parrilla") && amenity === "restaurant" && /steak_house|barbecue|grill|argentin/.test(cuisine)) {
    return "parrilla";
  }
  if (cats.includes("pizza") && /pizza/.test(cuisine)) return "pizza";
  if (amenity === "bar" || amenity === "pub") return "bar";
  if (amenity === "cafe") return "cafe";
  if (amenity === "ice_cream") return "heladeria";
  if (shop === "bakery") return "panaderia";
  if (amenity === "pharmacy") return "farmacia";
  if (shop === "supermarket" || shop === "convenience") return "supermercado";
  if (amenity === "fast_food") return "comida_rapida";
  if (amenity === "fuel") return "estacion_servicio";
  if (shop === "kiosk") return "kiosco";
  if (shop === "convenience") return "kiosco";
  if (amenity === "restaurant") return "restaurante";
  return "restaurante";
}

// Rating/reseña si está mapeado en OSM (poco frecuente, pero existe)
function buildRating(tags) {
  const raw = tags.stars || tags.rating || tags["review:stars"];
  if (!raw) return null;
  const n = parseFloat(String(raw).replace(",", "."));
  if (Number.isNaN(n)) return null;
  return Math.max(0, Math.min(5, n));
}

// ---------- Horarios: parser simple de opening_hours (OSM) ----------
const DOW_MAP = { mo: 1, tu: 2, we: 3, th: 4, fr: 5, sa: 6, su: 0 };
function isOpenNow(openingHours, now = new Date()) {
  if (!openingHours) return null; // sin dato: no filtramos
  const raw = openingHours.trim();
  if (/24\/7/i.test(raw)) return true;
  const day = now.getDay();
  const minutes = now.getHours() * 60 + now.getMinutes();

  // Separa por ";" y evalúa cada regla; la última regla que matchea el día manda.
  const rules = raw.split(";").map((r) => r.trim()).filter(Boolean);
  let result = null;
  for (const rule of rules) {
    const m = rule.match(/^([a-zA-Z,\-]+)?\s*(.*)$/);
    if (!m) continue;
    const dowPart = m[1];
    const rest = m[2] || "";
    if (/off|closed/i.test(rest) && !/\d/.test(rest)) {
      if (!dowPart || matchesDow(dowPart, day)) result = false;
      continue;
    }
    if (!dowPart || matchesDow(dowPart, day)) {
      const ranges = rest.match(/\d{1,2}:\d{2}\s*-\s*\d{1,2}:\d{2}/g);
      if (!ranges) continue;
      const open = ranges.some((r) => {
        const [start, end] = r.split("-").map((t) => t.trim());
        const [sh, sm] = start.split(":").map(Number);
        const [eh, em] = end.split(":").map(Number);
        const startMin = sh * 60 + sm;
        let endMin = eh * 60 + em;
        if (endMin <= startMin) endMin += 24 * 60; // cruza medianoche
        return minutes >= startMin && minutes <= endMin;
      });
      result = open;
    }
  }
  return result; // null = no se pudo determinar (no filtra)
}

function matchesDow(dowPart, day) {
  if (!dowPart) return true;
  const parts = dowPart.toLowerCase().split(",");
  return parts.some((p) => {
    if (p.includes("-")) {
      const [a, b] = p.split("-");
      const da = DOW_MAP[a], db = DOW_MAP[b];
      if (da == null || db == null) return false;
      if (da <= db) return day >= da && day <= db;
      return day >= da || day <= db; // rango que cruza la semana (ej. Fr-Su... raro)
    }
    return DOW_MAP[p] === day;
  });
}

function buildAddress(tags) {
  const parts = [];
  if (tags["addr:street"]) {
    parts.push(tags["addr:street"] + (tags["addr:housenumber"] ? " " + tags["addr:housenumber"] : ""));
  }
  return parts.join(", ");
}

// ---------- Nominatim: dirección completa on-demand ----------
// Solo se llama al abrir la ficha de un lugar (no en la búsqueda general) para
// respetar el límite de uso de Nominatim (~1 req/seg) y no gastar de más.
const geocodeCache = new Map();
async function reverseGeocode(lat, lon) {
  const key = `${roundCoord(lat)},${roundCoord(lon)}`;
  if (geocodeCache.has(key)) return geocodeCache.get(key);
  try {
    const url = `https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=${lat}&lon=${lon}&zoom=18&addressdetails=1`;
    const res = await fetch(url, { headers: { "Accept-Language": "es" } });
    if (!res.ok) return null;
    const data = await res.json();
    const a = data.address || {};
    const street = a.road || a.pedestrian || a.footway || a.path || "";
    const number = a.house_number || "";
    const area = a.suburb || a.neighbourhood || a.city_district || "";
    const parts = [street ? street + (number ? " " + number : "") : "", area].filter(Boolean);
    const result = parts.join(", ") || null;
    geocodeCache.set(key, result);
    return result;
  } catch (e) {
    return null;
  }
}

function haversine(lat1, lon1, lat2, lon2) {
  const R = 6371000;
  const toRad = (d) => (d * Math.PI) / 180;
  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lon2 - lon1);
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLon / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

function formatDistance(m, isSlider = false) {
  if (isSlider) {
    return m >= 1000 ? `${(m / 1000).toFixed(1)} km` : `${m} m`;
  }
  return m >= 1000 ? `${(m / 1000).toFixed(1)} km` : `${Math.round(m)} m`;
}

// ---------- Tiempo a pie estimado ----------
// La distancia en línea recta subestima bastante lo que hay que caminar en
// una ciudad con cuadras, avenidas o vías. Compensamos con un factor de
// "manzaneo" urbano (no es una ruta real, pero acerca mucho más que la
// línea recta) y un ritmo de caminata promedio.
const WALK_URBAN_FACTOR = 1.3; // cuadras/rodeos vs. línea recta
const WALK_SPEED_M_MIN = 80; // ritmo urbano promedio, ~4.8 km/h

function estimateWalkMinutes(meters) {
  if (!(meters >= 0)) return null;
  const walkDistance = meters * WALK_URBAN_FACTOR;
  return Math.max(1, Math.round(walkDistance / WALK_SPEED_M_MIN));
}

function formatWalkTime(meters) {
  const min = estimateWalkMinutes(meters);
  if (min == null) return "";
  if (min >= 60) {
    const h = Math.floor(min / 60);
    const rest = min % 60;
    return rest === 0 ? `${h} h a pie` : `${h} h ${rest} min a pie`;
  }
  return `${min} min a pie`;
}

// ---------- Modo ahorro de datos ----------
// Cuando el usuario tiene el "ahorro de datos" del sistema activado o está
// en una conexión lenta (2G/3G), evitamos cargar las fotos de Wikimedia
// Commons en las tarjetas y mostramos el ícono de categoría en su lugar.
function getNetworkInfo() {
  return navigator.connection || navigator.mozConnection || navigator.webkitConnection || null;
}
function computeDataSaver() {
  const conn = getNetworkInfo();
  if (!conn) return false;
  if (conn.saveData) return true;
  if (conn.effectiveType && /2g|3g/i.test(conn.effectiveType)) return true;
  return false;
}
function shouldShowPhoto(contact) {
  return !!(contact && contact.photo) && !state.dataSaver;
}

// ---------- Render ----------
function applyFiltersAndSort() {
  let list = state.results.slice();

  if (state.searchText) {
    const q = state.searchText.toLowerCase();
    list = list.filter((p) => p.name.toLowerCase().includes(q));
  }

  if (state.settings.openNowOnly) {
    list = list.filter((p) => isOpenNow(p.contact && p.contact.opening) !== false);
  }

  if (state.settings.wheelchairOnly) {
    list = list.filter((p) => p.wheelchair === "yes" || p.wheelchair === "designated" || p.wheelchair === "limited");
  }

  const sortBy = state.settings.sortBy || "dist";
  if (sortBy === "name") {
    list.sort((a, b) => a.name.localeCompare(b.name, "es"));
  } else if (sortBy === "category") {
    list.sort((a, b) => {
      const la = (CATEGORY_DEFS[a.category] || {}).label || a.category;
      const lb = (CATEGORY_DEFS[b.category] || {}).label || b.category;
      return la.localeCompare(lb, "es") || a.dist - b.dist;
    });
  } else {
    list.sort((a, b) => a.dist - b.dist);
  }

  state.filteredResults = list;
  return list;
}

function renderResults() {
  els.viewToggle.hidden = false;
  els.resultsToolbar.hidden = false;
  els.resultsStatus.hidden = false;
  if (els.busquedasIntro) els.busquedasIntro.hidden = true;
  setView(state.view);
  renderMapCatFilter();

  const expandBanner = radiusSuggestionBanner();

  if (state.results.length === 0) {
    els.resultsView.innerHTML = `<div class="empty-state">No encontramos lugares en ese radio. Probá ampliar la distancia o cambiar las categorías.${expandBanner ? `<br><br>${expandBanner}` : ""}</div>`;
    els.resultsStatus.textContent = "";
    updateMapMarkers();
    return;
  }

  const list = applyFiltersAndSort();

  if (list.length === 0) {
    els.resultsView.innerHTML = `<div class="empty-state">Ningún resultado coincide con el filtro actual.</div>`;
    els.resultsStatus.textContent = `${state.results.length} lugares encontrados · 0 visibles`;
    updateMapMarkers();
    return;
  }

  els.resultsStatus.textContent = (list.length === state.results.length
    ? `${state.results.length} lugares encontrados`
    : `${list.length} de ${state.results.length} lugares`) + (state.dataSaver ? " · 🐢 ahorro de datos" : "");

  if (!state.renderedCount) state.renderedCount = RESULTS_PAGE_SIZE;
  const visibleList = list.slice(0, state.renderedCount);
  const remaining = list.length - visibleList.length;

  els.resultsView.innerHTML = (expandBanner || "") + visibleList
    .map((p, i) => {
      const def = CATEGORY_DEFS[p.category] || CATEGORY_DEFS.restaurante;
      const c = p.contact || {};
      const isFav = isFavorite(p.id);
      const iconRow = [
        c.phone ? "📞" : "",
        c.website ? "🌐" : "",
        c.instagram ? "📷" : "",
        c.facebook ? "👍" : "",
        (p.wheelchair === "yes" || p.wheelchair === "designated" || p.wheelchair === "limited") ? "♿" : "",
      ].filter(Boolean).join(" ");
      const delay = Math.min(i, 10) * 0.035;
      const openState = isOpenNow(c.opening);
      const openChip = openState === true
        ? `<span class="status-chip status-open">Abierto</span>`
        : openState === false
        ? `<span class="status-chip status-closed">Cerrado</span>`
        : "";
      return `
        <button class="place-card card-enter" type="button" data-id="${p.id}" style="animation-delay:${delay}s">
          ${shouldShowPhoto(c) ? `<div class="place-thumb"><img src="${c.photo}" alt="" loading="lazy" decoding="async" /></div>` : `<div class="place-badge ${def.badgeClass}">${def.icon}</div>`}
          <div class="place-info">
            <p class="place-name">${escapeHtml(p.name)}</p>
            <div class="place-meta">
              <span>${def.label}</span>
              ${openChip}
              ${p.rating != null ? `<span class="place-rating">⭐ ${p.rating.toFixed(1)}</span>` : ""}
              <span class="place-walk">🚶 ${formatWalkTime(p.dist)}</span>
              ${p.address ? `<span>${escapeHtml(p.address)}</span>` : ""}
              ${iconRow ? `<span class="place-icons">${iconRow}</span>` : ""}
            </div>
          </div>
          <div class="place-dist">${formatDistance(p.dist)}</div>
          <button class="fav-star ${isFav ? "on" : ""}" type="button" data-fav-id="${p.id}" aria-label="Favorito" aria-pressed="${isFav}">${isFav ? "★" : "☆"}</button>
        </button>
      `;
    })
    .join("") + (remaining > 0
      ? `<button class="load-more-btn glass-panel" type="button" data-action="load-more">Cargar ${Math.min(remaining, RESULTS_PAGE_SIZE)} más (quedan ${remaining})</button>`
      : "");

  updateMapMarkers();
}

// ---------- Sugerencia de ampliar radio cuando hay pocos resultados ----------
function radiusSuggestionBanner() {
  if (state.radius >= 10000) return "";
  if (state.results.length === 0 || state.results.length < LOW_RESULTS_THRESHOLD) {
    const next = Math.min(10000, state.radius * 2);
    return `
      <div class="results-banner">
        <span>${state.results.length === 0 ? "Casi no hay resultados por acá." : "Encontramos pocos lugares."} Probá con más radio.</span>
        <button type="button" data-action="expand-radius" data-radius="${next}">Ampliar a ${formatDistance(next, true)}</button>
      </div>
    `;
  }
  return "";
}

function expandRadiusAndSearch(newRadius) {
  state.radius = newRadius;
  els.radius.value = newRadius;
  els.radiusValue.textContent = formatDistance(newRadius, true);
  runSearch();
}

function findPlaceById(id) {
  return state.results.find((p) => String(p.id) === String(id))
    || state.filteredResults.find((p) => String(p.id) === String(id));
}

// ---------- Ficha de detalle (bottom sheet) ----------
els.resultsView.addEventListener("click", (e) => {
  const loadMoreBtn = e.target.closest("[data-action='load-more']");
  if (loadMoreBtn) {
    e.stopPropagation();
    state.renderedCount = (state.renderedCount || RESULTS_PAGE_SIZE) + RESULTS_PAGE_SIZE;
    renderResults();
    return;
  }
  const expandBtn = e.target.closest("[data-action='expand-radius']");
  if (expandBtn) {
    e.stopPropagation();
    expandRadiusAndSearch(Number(expandBtn.dataset.radius));
    return;
  }
  const star = e.target.closest(".fav-star");
  if (star) {
    e.stopPropagation();
    const p = findPlaceById(star.dataset.favId);
    if (p) toggleFavorite(p, star);
    return;
  }
  const card = e.target.closest(".place-card");
  if (!card) return;
  const p = findPlaceById(card.dataset.id);
  if (p) openPlaceSheet(p);
});

els.refreshResultsBtn.addEventListener("click", () => {
  if (!state.lastQuery) return;
  runSearch({ cats: state.lastQuery.cats, radius: state.lastQuery.radius, forceRefresh: true });
});

// ---------- Toolbar: texto, orden, abierto ahora ----------
let searchTextTimer = null;
els.searchText.addEventListener("input", () => {
  clearTimeout(searchTextTimer);
  searchTextTimer = setTimeout(() => {
    state.searchText = els.searchText.value.trim();
    state.renderedCount = RESULTS_PAGE_SIZE;
    renderResults();
  }, 180);
});

els.sortSelect.addEventListener("change", () => {
  state.settings.sortBy = els.sortSelect.value;
  saveSettings();
  state.renderedCount = RESULTS_PAGE_SIZE;
  renderResults();
});

els.openNowToggle.addEventListener("click", () => {
  state.settings.openNowOnly = !state.settings.openNowOnly;
  els.openNowToggle.classList.toggle("on", state.settings.openNowOnly);
  els.openNowToggle.setAttribute("aria-pressed", String(state.settings.openNowOnly));
  saveSettings();
  state.renderedCount = RESULTS_PAGE_SIZE;
  renderResults();
});

if (els.wheelchairToggle) {
  els.wheelchairToggle.addEventListener("click", () => {
    state.settings.wheelchairOnly = !state.settings.wheelchairOnly;
    els.wheelchairToggle.classList.toggle("on", state.settings.wheelchairOnly);
    els.wheelchairToggle.setAttribute("aria-pressed", String(state.settings.wheelchairOnly));
    saveSettings();
    state.renderedCount = RESULTS_PAGE_SIZE;
    renderResults();
  });
}

// ---------- Foco accesible del bottom sheet ----------
let sheetTriggerEl = null;
function openSheetOverlay() {
  sheetTriggerEl = document.activeElement;
  els.sheetOverlay.hidden = false;
  requestAnimationFrame(() => {
    els.sheetOverlay.classList.add("open");
    els.sheetClose.focus();
  });
}

function openPlaceSheet(p) {
  // Notificación si el usuario está muy cerca de un favorito
  if (isFavorite(p.id) && state.userLat && p.dist != null && p.dist <= 100) {
    showToast(`¡Estás a ${Math.round(p.dist)} m de ${p.name}! 📍`);
  }
  const def = CATEGORY_DEFS[p.category] || CATEGORY_DEFS.restaurante;
  const c = p.contact || {};
  const mapsUrl = `https://www.google.com/maps/dir/?api=1&destination=${p.lat},${p.lon}`;
  const wazeUrl = `https://waze.com/ul?ll=${p.lat},${p.lon}&navigate=yes`;
  // En iOS, geo: no abre Maps directamente desde el navegador; usamos la URL universal de Maps.
  // En Android, geo: sí abre el selector de apps nativo.
  const isAndroid = /android/i.test(navigator.userAgent);
  const nativeNavUrl = isAndroid
    ? `geo:${p.lat},${p.lon}?q=${p.lat},${p.lon}(${encodeURIComponent(p.name)})`
    : mapsUrl;
  const openState = isOpenNow(c.opening);
  const isFav = isFavorite(p.id);

  const actions = [];
  actions.push(`<button class="sheet-action primary" id="sheetNavBtn" type="button"><span>🧭</span>Cómo llegar</button>`);
  actions.push(`<a class="sheet-action" href="${wazeUrl}" target="_blank" rel="noopener"><span>🚗</span>Waze</a>`);
  if (c.phone) actions.push(`<a class="sheet-action" href="tel:${escapeHtml(c.phone.replace(/\s+/g, ""))}"><span>📞</span>Llamar</a>`);
  if (c.website) actions.push(`<a class="sheet-action" href="${escapeHtml(c.website)}" target="_blank" rel="noopener"><span>🌐</span>Web</a>`);
  if (c.instagram) actions.push(`<a class="sheet-action" href="${escapeHtml(c.instagram)}" target="_blank" rel="noopener"><span>📷</span>Instagram</a>`);
  if (c.facebook) actions.push(`<a class="sheet-action" href="${escapeHtml(c.facebook)}" target="_blank" rel="noopener"><span>👍</span>Facebook</a>`);
  actions.push(`<button class="sheet-action" id="sheetShareBtn" type="button"><span>📲</span>Compartir</button>`);
  actions.push(`<button class="sheet-action" id="sheetShareCardBtn" type="button"><span>🖼️</span>Tarjeta</button>`);

  els.sheetContent.innerHTML = `
    ${shouldShowPhoto(c)
      ? `<div class="sheet-photo" style="background-image:url('${c.photo}')"></div>`
      : `<div class="sheet-photo sheet-photo-placeholder ${def.badgeClass}"><span>${def.icon}</span></div>`}
    <div class="sheet-header">
      <div class="place-badge ${def.badgeClass}">${def.icon}</div>
      <div class="sheet-title-wrap">
        <h3 class="sheet-title">${escapeHtml(p.name)}</h3>
        <p class="sheet-subtitle">${def.label} · ${formatDistance(p.dist)} · 🚶 ${formatWalkTime(p.dist)}<span id="sheetAddressPart">${p.address ? " · " + escapeHtml(p.address) : ""}</span>${p.rating != null ? ` · <span class="sheet-rating">⭐ ${p.rating.toFixed(1)}</span>` : ""}</p>
      </div>
      <button class="sheet-fav-star ${isFav ? "on" : ""}" id="sheetFavBtn" type="button" aria-label="Favorito" aria-pressed="${isFav}">${isFav ? "★" : "☆"}</button>
    </div>
    ${c.opening ? `<p class="sheet-hours">🕒 ${escapeHtml(c.opening)}${openState === true ? ' <span style="color:var(--status-open)">· Abierto ahora</span>' : openState === false ? ' <span style="color:var(--status-closed)">· Cerrado ahora</span>' : ""}</p>` : ""}
    <div class="sheet-actions">${actions.join("")}</div>
    ${(!c.phone && !c.website && !c.instagram && !c.facebook) ? `<p class="sheet-empty-note">Este lugar todavía no tiene datos de contacto cargados en OpenStreetMap.</p>` : ""}
    <div class="sheet-note-wrap">
      <span class="sheet-note-label">Tu nota</span>
      <textarea class="sheet-note-input" id="sheetNoteInput" placeholder="Ej: pedir la de fernet, cerrado los lunes…">${escapeHtml(getNote(p.id))}</textarea>
    </div>
    <button class="sheet-report-btn" id="sheetReportBtn" type="button">🚫 Reportar cerrado / dato incorrecto</button>
  `;

  openSheetOverlay();
  els.sheet.dataset.placeId = p.id;

  if (!p.address) {
    reverseGeocode(p.lat, p.lon).then((addr) => {
      if (!addr) return;
      if (els.sheet.dataset.placeId !== String(p.id)) return; // el usuario ya abrió otra ficha
      const el = document.getElementById("sheetAddressPart");
      if (el) el.textContent = " · " + addr;
    });
  }

  const navBtn = document.getElementById("sheetNavBtn");
  if (navBtn) navBtn.addEventListener("click", () => {
    // En Android abrimos geo: para que el sistema muestre el selector de apps.
    // En iOS abrimos Google Maps con indicaciones desde origen actual.
    window.open(nativeNavUrl, "_blank", "noopener");
  });

  const shareBtn = document.getElementById("sheetShareBtn");
  if (shareBtn) shareBtn.addEventListener("click", () => sharePlace(p));

  const shareCardBtn = document.getElementById("sheetShareCardBtn");
  if (shareCardBtn) shareCardBtn.addEventListener("click", () => sharePlaceCard(p));

  const favBtn = document.getElementById("sheetFavBtn");
  if (favBtn) favBtn.addEventListener("click", () => toggleFavorite(p, favBtn));

  const noteInput = document.getElementById("sheetNoteInput");
  if (noteInput) {
    let noteTimer = null;
    noteInput.addEventListener("input", () => {
      clearTimeout(noteTimer);
      noteTimer = setTimeout(() => setNote(p.id, noteInput.value), 300);
    });
  }

  const reportBtn = document.getElementById("sheetReportBtn");
  if (reportBtn) {
    reportBtn.addEventListener("click", () => {
      if (confirm(`¿Ocultar "${p.name}" de tus búsquedas? Podés restaurarlo desde el Menú.`)) {
        reportPlace(p);
      }
    });
  }
}

function closePlaceSheet() {
  els.sheetOverlay.classList.remove("open");
  setTimeout(() => { els.sheetOverlay.hidden = true; }, 220);
  if (sheetTriggerEl && typeof sheetTriggerEl.focus === "function") {
    sheetTriggerEl.focus();
  }
  sheetTriggerEl = null;
}

els.sheetClose.addEventListener("click", closePlaceSheet);
els.sheetOverlay.addEventListener("click", (e) => {
  if (e.target === els.sheetOverlay) closePlaceSheet();
});

// Lector de pantalla: Escape cierra, Tab queda atrapado dentro del sheet
els.sheetOverlay.addEventListener("keydown", (e) => {
  if (e.key === "Escape") {
    e.stopPropagation();
    closePlaceSheet();
    return;
  }
  if (e.key !== "Tab") return;
  const focusables = Array.prototype.slice.call(
    els.sheet.querySelectorAll('a[href], button:not([disabled]), textarea, input, [tabindex]:not([tabindex="-1"])')
  );
  if (!focusables.length) return;
  const first = focusables[0];
  const last = focusables[focusables.length - 1];
  if (e.shiftKey && document.activeElement === first) {
    e.preventDefault();
    last.focus();
  } else if (!e.shiftKey && document.activeElement === last) {
    e.preventDefault();
    first.focus();
  }
});

async function sharePlace(p) {
  const mapsUrl = `https://www.google.com/maps/search/?api=1&query=${p.lat},${p.lon}`;
  const text = `${p.name} — ${formatDistance(p.dist)}\n${mapsUrl}`;
  if (navigator.share) {
    try {
      await navigator.share({ title: p.name, text });
      return;
    } catch (err) {
      if (err && err.name === "AbortError") return;
    }
  }
  window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, "_blank", "noopener");
}

function escapeHtml(str) {
  const div = document.createElement("div");
  div.textContent = str;
  return div.innerHTML;
}

// ---------- Mapa (Leaflet) ----------
function initMapIfNeeded() {
  if (state.map) return;
  if (typeof L === "undefined") {
    // Leaflet no llegó a cargar (CDN bloqueado / sin conexión en ese momento).
    // No dejamos que esto rompa el resto de la búsqueda.
    console.warn("Leaflet no está disponible; el mapa queda deshabilitado.");
    return;
  }
  state.map = L.map("map", { zoomControl: true });
  L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
    attribution: "&copy; OpenStreetMap contributors",
    maxZoom: 19,
  }).addTo(state.map);
  state.markersLayer = L.layerGroup().addTo(state.map);
  state.map.setView([state.userLat || 0, state.userLon || 0], 15);
  state.map.on("zoomend", () => updateMapMarkers(false));
}

function updateMapMarkers(fitBounds = true) {
  if (!state.userLat) return;
  try {
    initMapIfNeeded();
  } catch (err) {
    console.warn("No se pudo inicializar el mapa", err);
  }
  if (!state.map || !state.markersLayer) return;
  try {
    updateMapMarkersInner(fitBounds);
  } catch (err) {
    console.warn("No se pudieron actualizar los marcadores del mapa", err);
  }
}

function updateMapMarkersInner(fitBounds) {
  state.markersLayer.clearLayers();

  const userIcon = L.divIcon({
    className: "",
    html: `<div style="width:16px;height:16px;border-radius:50%;background:#0A84FF;border:2px solid #fff;box-shadow:0 0 0 4px rgba(10,132,255,0.25);"></div>`,
    iconSize: [16, 16],
    iconAnchor: [8, 8],
  });
  L.marker([state.userLat, state.userLon], { icon: userIcon })
    .addTo(state.markersLayer)
    .bindPopup("<strong>Estás acá</strong>");

  if (state.car) {
    const carIcon = L.divIcon({
      className: "",
      html: `<div style="font-size:18px;filter:drop-shadow(0 1px 2px rgba(0,0,0,0.6));">🚗</div>`,
      iconSize: [22, 22],
      iconAnchor: [11, 11],
    });
    L.marker([state.car.lat, state.car.lon], { icon: carIcon })
      .addTo(state.markersLayer)
      .bindPopup("<strong>Tu auto</strong>");
  }

  const visible = state.results.filter((p) => state.mapCatFilter.size === 0 || state.mapCatFilter.has(p.category));
  const bounds = [[state.userLat, state.userLon]];
  visible.forEach((p) => bounds.push([p.lat, p.lon]));

  renderClusteredMarkers(visible);

  if (fitBounds) {
    if (bounds.length > 1) {
      state.map.flyToBounds(bounds, { padding: [30, 30], maxZoom: 16, duration: 0.7 });
    } else {
      state.map.flyTo([state.userLat, state.userLon], 15, { duration: 0.7 });
    }
  }
}

// Clustering simple basado en distancia en píxeles de pantalla al zoom actual.
function renderClusteredMarkers(points) {
  if (!state.map || points.length === 0) return;
  const zoom = state.map.getZoom();
  const projected = points.map((p) => ({ p, pt: state.map.project([p.lat, p.lon], zoom) }));
  const threshold = points.length > 8 ? 42 : 0; // solo agrupamos si hay bastantes resultados
  const used = new Array(projected.length).fill(false);
  const groups = [];

  for (let i = 0; i < projected.length; i++) {
    if (used[i]) continue;
    const group = [projected[i]];
    used[i] = true;
    if (threshold > 0) {
      for (let j = i + 1; j < projected.length; j++) {
        if (used[j]) continue;
        const dx = projected[i].pt.x - projected[j].pt.x;
        const dy = projected[i].pt.y - projected[j].pt.y;
        if (Math.sqrt(dx * dx + dy * dy) < threshold) {
          group.push(projected[j]);
          used[j] = true;
        }
      }
    }
    groups.push(group);
  }

  groups.forEach((group, gi) => {
    const delay = Math.min(gi, 12) * 0.03;
    if (group.length === 1) {
      const p = group[0].p;
      const def = CATEGORY_DEFS[p.category] || CATEGORY_DEFS.restaurante;
      const closed = isOpenNow((p.contact || {}).opening) === false;
      const icon = L.divIcon({
        className: "",
        html: `<div class="marker-enter" style="font-size:18px;line-height:1;filter:drop-shadow(0 1px 2px rgba(0,0,0,0.6))${closed ? " grayscale(0.85)" : ""};opacity:${closed ? 0.55 : 1};animation-delay:${delay}s">${def.icon}</div>`,
        iconSize: [24, 24],
        iconAnchor: [12, 12],
      });
      L.marker([p.lat, p.lon], { icon })
        .addTo(state.markersLayer)
        .bindPopup(`<strong>${escapeHtml(p.name)}</strong><br>${def.label} · ${formatDistance(p.dist)} · 🚶 ${formatWalkTime(p.dist)}${closed ? " · <span style=\"color:var(--status-closed)\">Cerrado</span>" : ""}`);
    } else {
      const latSum = group.reduce((s, g) => s + g.p.lat, 0);
      const lonSum = group.reduce((s, g) => s + g.p.lon, 0);
      const center = [latSum / group.length, lonSum / group.length];
      const icon = L.divIcon({
        className: "",
        html: `<div class="map-cluster marker-enter" style="animation-delay:${delay}s">${group.length}</div>`,
        iconSize: [36, 36],
        iconAnchor: [18, 18],
      });
      const marker = L.marker(center, { icon }).addTo(state.markersLayer);
      marker.on("click", () => {
        state.map.flyTo(center, Math.min(19, state.map.getZoom() + 2), { duration: 0.6 });
      });
    }
  });
}

function renderMapCatFilter() {
  if (!els.mapCatFilter) return;
  const cats = [...new Set(state.results.map((p) => p.category))];
  if (cats.length <= 1) {
    els.mapCatFilter.innerHTML = "";
    return;
  }
  els.mapCatFilter.innerHTML = cats
    .map((cat) => {
      const def = CATEGORY_DEFS[cat] || {};
      const on = state.mapCatFilter.has(cat);
      return `<button class="map-cat-chip ${on ? "on" : ""}" data-cat="${cat}" type="button">${def.icon || ""} ${def.label || cat}</button>`;
    })
    .join("");
}

if (els.mapCatFilter) {
  els.mapCatFilter.addEventListener("click", (e) => {
    const btn = e.target.closest(".map-cat-chip");
    if (!btn) return;
    const cat = btn.dataset.cat;
    if (state.mapCatFilter.has(cat)) state.mapCatFilter.delete(cat);
    else state.mapCatFilter.add(cat);
    renderMapCatFilter();
    updateMapMarkers(false);
  });
}

// ---------- Favoritos ----------
// ---------- Lugares reportados (cerrado / dato incorrecto) ----------
// Se ocultan localmente de futuras búsquedas; no se envía nada a ningún lado.
function loadHiddenPlaces() {
  try {
    const raw = localStorage.getItem(HIDDEN_PLACES_KEY);
    return raw ? new Set(JSON.parse(raw)) : new Set();
  } catch (e) { return new Set(); }
}
function saveHiddenPlaces() {
  try {
    localStorage.setItem(HIDDEN_PLACES_KEY, JSON.stringify([...state.hiddenPlaces]));
  } catch (e) { /* sin espacio: no es crítico */ }
}
function reportPlace(p) {
  state.hiddenPlaces.add(String(p.id));
  saveHiddenPlaces();
  state.results = state.results.filter((r) => String(r.id) !== String(p.id));
  state.renderedCount = state.renderedCount || RESULTS_PAGE_SIZE;
  closePlaceSheet();
  renderResults();
  showToast("Lo ocultamos de tus búsquedas. ¡Gracias por avisar! 🙏");
}

function loadFavorites() {
  try {
    const raw = localStorage.getItem(FAVORITES_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch (e) { return []; }
}
function saveFavoritesList() {
  try {
    localStorage.setItem(FAVORITES_KEY, JSON.stringify(state.favorites));
  } catch (e) {
    showToast("No pudimos guardar: sin espacio en el dispositivo");
  }
}
function isFavorite(id) {
  return state.favorites.some((f) => String(f.id) === String(id));
}
function toggleFavorite(p, btnEl) {
  const idx = state.favorites.findIndex((f) => String(f.id) === String(p.id));
  if (idx >= 0) {
    state.favorites.splice(idx, 1);
    showToast("Sacado de favoritos");
  } else {
    state.favorites.unshift({
      id: p.id, name: p.name, lat: p.lat, lon: p.lon,
      category: p.category, address: p.address, contact: p.contact, rating: p.rating,
      savedAt: Date.now(),
    });
    showToast("Agregado a favoritos ⭐");
  }
  saveFavoritesList();
  updateFavBadge();
  if (state.mapaMap) updateMapaMarkers();
  const nowFav = isFavorite(p.id);
  document.querySelectorAll(`[data-fav-id="${p.id}"]`).forEach((el) => {
    el.classList.toggle("on", nowFav);
    el.setAttribute("aria-pressed", String(nowFav));
    el.textContent = nowFav ? "★" : "☆";
    if (nowFav) {
      el.classList.remove("pop");
      void el.offsetWidth;
      el.classList.add("pop");
      el.addEventListener("animationend", () => el.classList.remove("pop"), { once: true });
    }
  });
  const sheetFav = document.getElementById("sheetFavBtn");
  if (sheetFav) {
    sheetFav.classList.toggle("on", nowFav);
    sheetFav.setAttribute("aria-pressed", String(nowFav));
    sheetFav.textContent = nowFav ? "★" : "☆";
    if (nowFav) {
      sheetFav.classList.remove("pop");
      void sheetFav.offsetWidth;
      sheetFav.classList.add("pop");
      sheetFav.addEventListener("animationend", () => sheetFav.classList.remove("pop"), { once: true });
    }
  }
  if (state.activeTab === "favoritos") renderFavorites();
}
function updateFavBadge() {
  const n = state.favorites.length;
  els.favBadge.hidden = n === 0;
  els.favBadge.textContent = n > 99 ? "99+" : String(n);
}
function renderFavorites() {
  els.compareToggleBtn.hidden = state.favorites.length < 2;
  if (state.favorites.length < 2 && state.compareMode) {
    state.compareMode = false;
    state.compareSelection = [];
  }
  if (state.favorites.length === 0) {
    els.favoritesList.innerHTML = `<div class="empty-favorites">Todavía no tenés lugares favoritos.<br>Tocá la ⭐ en cualquier lugar para guardarlo acá.</div>`;
    updateCompareBar();
    return;
  }
  els.favoritesList.innerHTML = state.favorites
    .map((p) => {
      const def = CATEGORY_DEFS[p.category] || CATEGORY_DEFS.restaurante;
      const c = p.contact || {};
      const selected = state.compareSelection.includes(String(p.id));
      return `
        <button class="place-card ${selected ? "comparing" : ""}" type="button" data-fav-open="${p.id}">
          ${shouldShowPhoto(c) ? `<div class="place-thumb" style="background-image:url('${c.photo}')"></div>` : `<div class="place-badge ${def.badgeClass}">${def.icon}</div>`}
          <div class="place-info">
            <p class="place-name">${escapeHtml(p.name)}</p>
            <div class="place-meta">
              <span>${def.label}</span>
              ${p.rating != null ? `<span class="place-rating">⭐ ${p.rating.toFixed(1)}</span>` : ""}
              ${p.address ? `<span>${escapeHtml(p.address)}</span>` : ""}
              ${getNote(p.id) ? `<span>📝 ${escapeHtml(getNote(p.id))}</span>` : ""}
            </div>
          </div>
          ${state.compareMode
            ? `<span class="fav-star ${selected ? "on" : ""}" aria-hidden="true">${selected ? "✅" : "⬜"}</span>`
            : `<button class="fav-star on" type="button" data-fav-id="${p.id}" aria-label="Quitar favorito" aria-pressed="true">★</button>`}
        </button>
      `;
    })
    .join("");
  updateCompareBar();
}

// ---------- Comparar favoritos lado a lado ----------
els.compareToggleBtn.addEventListener("click", () => {
  state.compareMode = !state.compareMode;
  state.compareSelection = [];
  els.compareToggleBtn.classList.toggle("on", state.compareMode);
  els.compareToggleBtn.setAttribute("aria-pressed", String(state.compareMode));
  els.compareToggleBtn.textContent = state.compareMode ? "Cancelar" : "Comparar";
  renderFavorites();
});

function updateCompareBar() {
  const n = state.compareSelection.length;
  els.compareBarBtn.hidden = !state.compareMode || n < 2;
  els.compareBarBtn.disabled = n < 2;
  els.compareCount.textContent = String(n);
}

els.compareBarBtn.addEventListener("click", () => {
  const places = state.compareSelection
    .map((id) => state.favorites.find((f) => String(f.id) === id))
    .filter(Boolean);
  if (places.length < 2) return;
  openCompareOverlay(places);
});

function openCompareOverlay(places) {
  els.compareContent.innerHTML = `
    <h3 class="sheet-title" style="margin-bottom:10px;">Comparar lugares</h3>
    <div class="compare-table">
      ${places
        .map((p) => {
          const def = CATEGORY_DEFS[p.category] || CATEGORY_DEFS.restaurante;
          const dist = state.userLat ? haversine(state.userLat, state.userLon, p.lat, p.lon) : null;
          const openState = isOpenNow((p.contact || {}).opening);
          const openLabel = openState === true
            ? '<span style="color:var(--status-open)">Abierto ahora</span>'
            : openState === false
            ? '<span style="color:var(--status-closed)">Cerrado ahora</span>'
            : "Sin datos de horario";
          return `
            <div class="compare-col">
              <h4>${def.icon} ${escapeHtml(p.name)}</h4>
              <div class="compare-row"><span>Categoría</span><strong>${def.label}</strong></div>
              <div class="compare-row"><span>Distancia</span><strong>${dist != null ? formatDistance(dist) : "—"}</strong></div>
              <div class="compare-row"><span>Estado</span><strong>${openLabel}</strong></div>
              <div class="compare-row"><span>Rating</span><strong>${p.rating != null ? "⭐ " + p.rating.toFixed(1) : "—"}</strong></div>
            </div>
          `;
        })
        .join("")}
    </div>
  `;
  els.compareOverlay.hidden = false;
  requestAnimationFrame(() => {
    els.compareOverlay.classList.add("open");
    els.compareClose.focus();
  });
}

function closeCompareOverlay() {
  els.compareOverlay.classList.remove("open");
  setTimeout(() => { els.compareOverlay.hidden = true; }, 220);
}

els.compareClose.addEventListener("click", closeCompareOverlay);
els.compareOverlay.addEventListener("click", (e) => {
  if (e.target === els.compareOverlay) closeCompareOverlay();
});
els.compareOverlay.addEventListener("keydown", (e) => trapModalKeydown(e, els.compareOverlay, closeCompareOverlay));
els.favoritesList.addEventListener("click", (e) => {
  const star = e.target.closest(".fav-star");
  if (star && star.dataset.favId) {
    e.stopPropagation();
    const p = state.favorites.find((f) => String(f.id) === String(star.dataset.favId));
    if (p) toggleFavorite(p);
    return;
  }
  const card = e.target.closest("[data-fav-open]");
  if (!card) return;
  const id = String(card.dataset.favOpen);

  if (state.compareMode) {
    const idx = state.compareSelection.indexOf(id);
    if (idx >= 0) {
      state.compareSelection.splice(idx, 1);
    } else if (state.compareSelection.length < 3) {
      state.compareSelection.push(id);
    } else {
      showToast("Podés comparar hasta 3 lugares");
    }
    renderFavorites();
    return;
  }

  const p = state.favorites.find((f) => String(f.id) === id);
  if (p) {
    p.dist = state.userLat ? haversine(state.userLat, state.userLon, p.lat, p.lon) : 0;
    openPlaceSheet(p);
  }
});

// ---------- Notas por lugar ----------
function loadNotes() {
  try {
    const raw = localStorage.getItem(NOTES_KEY);
    return raw ? JSON.parse(raw) : {};
  } catch (e) { return {}; }
}
function saveNotesMap() {
  try {
    localStorage.setItem(NOTES_KEY, JSON.stringify(state.notes));
  } catch (e) {
    showToast("No pudimos guardar la nota: sin espacio en el dispositivo");
  }
}
function getNote(id) { return state.notes[id] || ""; }
function setNote(id, text) {
  if (text && text.trim()) state.notes[id] = text.trim();
  else delete state.notes[id];
  saveNotesMap();
}

// ---------- Búsquedas favoritas (guardadas con nombre) ----------
function loadSavedSearches() {
  try {
    const raw = localStorage.getItem(SAVED_SEARCHES_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch (e) { return []; }
}
function saveSavedSearchesList() {
  try {
    localStorage.setItem(SAVED_SEARCHES_KEY, JSON.stringify(state.savedSearches));
  } catch (e) {
    showToast("No pudimos guardar: sin espacio en el dispositivo");
  }
}
function renderSavedSearches() {
  if (state.savedSearches.length === 0) {
    els.savedSearchesTitle.hidden = true;
    els.savedSearchesList.innerHTML = "";
    return;
  }
  els.savedSearchesTitle.hidden = false;
  els.savedSearchesList.innerHTML = state.savedSearches
    .map((s, idx) => {
      const icons = (s.cats && s.cats.length ? s.cats : Object.keys(CATEGORY_DEFS))
        .slice(0, 4).map((c) => (CATEGORY_DEFS[c] ? CATEGORY_DEFS[c].icon : "")).join(" ");
      return `
        <button class="history-card saved-search-card" data-saved-idx="${idx}">
          <span class="history-icons">${icons || "🔎"}</span>
          <span class="history-info">
            <p class="history-title">${escapeHtml(s.name)}</p>
            <span class="history-meta"><span>${formatDistance(s.radius, true)}</span></span>
          </span>
          <span class="history-replay" aria-hidden="true">↻</span>
          <button class="saved-search-delete" type="button" data-saved-delete="${idx}" aria-label="Borrar">✕</button>
        </button>
      `;
    })
    .join("");
}
els.savedSearchesList.addEventListener("click", (e) => {
  const del = e.target.closest("[data-saved-delete]");
  if (del) {
    e.stopPropagation();
    state.savedSearches.splice(Number(del.dataset.savedDelete), 1);
    saveSavedSearchesList();
    renderSavedSearches();
    showToast("Búsqueda guardada eliminada");
    return;
  }
  const card = e.target.closest("[data-saved-idx]");
  if (!card) return;
  const s = state.savedSearches[Number(card.dataset.savedIdx)];
  if (!s) return;
  runSearch({ cats: s.cats, radius: s.radius });
});

// ---------- Combos de categorías (atajos sin ubicación fija) ----------
// Distinto de las "búsquedas favoritas": esto no guarda radio ni ubicación,
// solo un conjunto de categorías para no tener que tildarlas de nuevo cada
// vez (ej: "Previa" = bar + kiosco).
function loadCombos() {
  try {
    const raw = localStorage.getItem(COMBOS_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      return Array.isArray(parsed) ? parsed : DEFAULT_COMBOS.slice();
    }
    saveCombosList(DEFAULT_COMBOS);
    return DEFAULT_COMBOS.slice();
  } catch (e) {
    return DEFAULT_COMBOS.slice();
  }
}
function saveCombosList(list) {
  try { localStorage.setItem(COMBOS_KEY, JSON.stringify(list)); } catch (e) {}
}
function comboIsActive(combo) {
  const cats = (combo.cats || []).filter((c) => CATEGORY_DEFS[c]);
  if (cats.length === 0) return false;
  return state.selected.size === cats.length && cats.every((c) => state.selected.has(c));
}
function renderCombos() {
  if (!els.combosRow) return;
  if (state.combos.length === 0) {
    els.combosRow.innerHTML = `<span class="combos-empty">Elegí categorías y tocá “+ Combo” para guardar un atajo</span>`;
    return;
  }
  els.combosRow.innerHTML = state.combos
    .map((combo, idx) => {
      const cats = (combo.cats || []).filter((c) => CATEGORY_DEFS[c]);
      const icons = cats.map((c) => CATEGORY_DEFS[c].icon).join("");
      const active = comboIsActive(combo);
      return `
        <span class="chip-toggle combo-chip ${active ? "on" : ""}" data-combo-idx="${idx}" role="button" tabindex="0" aria-pressed="${active}">
          <span class="combo-chip-label">${combo.icon || icons || "🔖"} ${escapeHtml(combo.name)}</span>
          <span class="combo-delete" data-combo-delete="${idx}" role="button" tabindex="0" aria-label="Borrar combo ${escapeHtml(combo.name)}">✕</span>
        </span>
      `;
    })
    .join("");
}
function applyCombo(combo) {
  const cats = (combo.cats || []).filter((c) => CATEGORY_DEFS[c]);
  if (cats.length === 0) {
    showToast("Este combo no tiene categorías válidas");
    return;
  }
  state.selected = new Set(cats);
  document.querySelectorAll(".cat-card").forEach((card) => {
    const isSel = state.selected.has(card.dataset.cat);
    card.classList.toggle("selected", isSel);
    card.setAttribute("aria-pressed", String(isSel));
  });
  renderCombos();
  showToast(`Combo "${combo.name}" aplicado — tocá Buscar`);
}
function deleteCombo(idx) {
  const combo = state.combos[idx];
  if (!combo) return;
  if (!confirm(`¿Borrar el combo "${combo.name}"?`)) return;
  state.combos.splice(idx, 1);
  saveCombosList(state.combos);
  renderCombos();
  showToast("Combo eliminado");
}
if (els.combosRow) {
  els.combosRow.addEventListener("click", (e) => {
    const del = e.target.closest("[data-combo-delete]");
    if (del) {
      e.stopPropagation();
      deleteCombo(Number(del.dataset.comboDelete));
      return;
    }
    const chip = e.target.closest("[data-combo-idx]");
    if (!chip) return;
    const combo = state.combos[Number(chip.dataset.comboIdx)];
    if (combo) applyCombo(combo);
  });
  els.combosRow.addEventListener("keydown", (e) => {
    if (e.key !== "Enter" && e.key !== " ") return;
    const target = e.target.closest("[data-combo-idx],[data-combo-delete]");
    if (!target) return;
    e.preventDefault();
    target.click();
  });
}
if (els.comboAddBtn) {
  els.comboAddBtn.addEventListener("click", () => {
    if (state.selected.size === 0) {
      showToast("Elegí al menos una categoría para guardarla como combo");
      return;
    }
    const name = prompt("Nombre para este combo (ej: Previa, Domingo con la familia):");
    if (!name || !name.trim()) return;
    const cats = [...state.selected];
    const icon = CATEGORY_DEFS[cats[0]] ? CATEGORY_DEFS[cats[0]].icon : "🔖";
    state.combos.push({ id: `custom_${Date.now()}`, name: name.trim().slice(0, 28), icon, cats });
    saveCombosList(state.combos);
    renderCombos();
    showToast("Combo guardado");
  });
}

// ---------- Configuración (radio/categorías default, orden, accento) ----------
function loadSettings() {
  try {
    const raw = localStorage.getItem(SETTINGS_KEY);
    return raw ? { ...state.settings, ...JSON.parse(raw) } : state.settings;
  } catch (e) { return state.settings; }
}
function saveSettings() {
  try { localStorage.setItem(SETTINGS_KEY, JSON.stringify(state.settings)); } catch (e) {}
}
function applyAccent(name) {
  const a = ACCENTS[name] || ACCENTS.amber;
  const root = document.documentElement.style;
  root.setProperty("--accent", a.accent);
  root.setProperty("--accent-glow", a.glow);
  root.setProperty("--accent-dim", a.dim);
  root.setProperty("--accent-glass", a.glass);
  root.setProperty("--border-hi", a.border);
  document.querySelectorAll(".swatch").forEach((s) => {
    const isSel = s.dataset.accent === name;
    s.classList.toggle("on", isSel);
    s.setAttribute("aria-pressed", String(isSel));
  });
}
if (els.accentSwatches) {
  els.accentSwatches.addEventListener("click", (e) => {
    const btn = e.target.closest(".swatch");
    if (!btn) return;
    state.settings.accent = btn.dataset.accent;
    applyAccent(state.settings.accent);
    saveSettings();
  });
}

// ---------- Dónde estacioné el auto ----------
function loadCar() {
  try {
    const raw = localStorage.getItem(CAR_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch (e) { return null; }
}
function saveCar() {
  try { localStorage.setItem(CAR_KEY, state.car ? JSON.stringify(state.car) : ""); } catch (e) {}
  if (state.mapaMap) updateMapaMarkers();
}
function updateCarMenuItem() {
  if (!els.menuCarTitle) return;
  if (state.car) {
    els.menuCarTitle.textContent = "Ver dónde estacioné";
    els.menuCarDesc.textContent = `Guardado ${formatRelativeTime(state.car.ts)}`;
  } else {
    els.menuCarTitle.textContent = "Guardar dónde estacioné";
    els.menuCarDesc.textContent = "Marcá la ubicación de tu auto";
  }
}
if (els.menuCar) {
  els.menuCar.addEventListener("click", async () => {
    if (!state.car) {
      try {
        const pos = await getPosition();
        state.car = { lat: pos.coords.latitude, lon: pos.coords.longitude, ts: Date.now() };
        saveCar();
        updateCarMenuItem();
        showToast("Guardamos dónde estacionaste 🚗");
      } catch (err) {
        showToast("No pudimos obtener tu ubicación");
      }
      return;
    }
    const dist = state.userLat ? haversine(state.userLat, state.userLon, state.car.lat, state.car.lon) : null;
    const mapsUrl = `https://www.google.com/maps/search/?api=1&query=${state.car.lat},${state.car.lon}`;
    els.sheetContent.innerHTML = `
      <div class="sheet-header">
        <div class="place-badge">🚗</div>
        <div class="sheet-title-wrap">
          <h3 class="sheet-title">Tu auto</h3>
          <p class="sheet-subtitle">Guardado ${formatRelativeTime(state.car.ts)}${dist != null ? " · " + formatDistance(dist) : ""}</p>
        </div>
      </div>
      <div class="sheet-actions">
        <a class="sheet-action primary" href="${mapsUrl}" target="_blank" rel="noopener"><span>🧭</span>Cómo llegar</a>
        <button class="sheet-action" id="carUpdateBtn" type="button"><span>📍</span>Actualizar</button>
        <button class="sheet-action" id="carClearBtn" type="button"><span>🗑️</span>Borrar</button>
      </div>
    `;
    openSheetOverlay();
    document.getElementById("carUpdateBtn").addEventListener("click", async () => {
      try {
        const pos = await getPosition();
        state.car = { lat: pos.coords.latitude, lon: pos.coords.longitude, ts: Date.now() };
        saveCar();
        updateCarMenuItem();
        showToast("Ubicación del auto actualizada");
        closePlaceSheet();
      } catch (err) { showToast("No pudimos obtener tu ubicación"); }
    });
    document.getElementById("carClearBtn").addEventListener("click", () => {
      state.car = null;
      saveCar();
      updateCarMenuItem();
      showToast("Borramos la ubicación del auto");
      closePlaceSheet();
    });
  });
}

// ---------- Sugerencia del día ----------
function todayKey() {
  const d = new Date();
  return `${d.getFullYear()}-${d.getMonth() + 1}-${d.getDate()}`;
}
function loadCachedSuggestion() {
  try {
    const raw = localStorage.getItem(SUGGESTION_KEY);
    const parsed = raw ? JSON.parse(raw) : null;
    return parsed && parsed.date === todayKey() ? parsed.place : null;
  } catch (e) { return null; }
}
function saveCachedSuggestion(place) {
  try { localStorage.setItem(SUGGESTION_KEY, JSON.stringify({ date: todayKey(), place })); } catch (e) {}
}
if (els.suggestionBtn) {
  els.suggestionBtn.addEventListener("click", async () => {
    const cached = loadCachedSuggestion();
    if (cached) {
      showSuggestionResult(cached);
      return;
    }
    els.suggestionSub.textContent = "Buscando algo lindo cerca tuyo…";
    try {
      const pos = await getPosition();
      const lat = pos.coords.latitude, lon = pos.coords.longitude;
      const cats = ["bar", "cafe", "restaurante", "heladeria"];
      const cat = cats[Math.floor(Math.random() * cats.length)];
      const elements = await queryOverpass([cat], lat, lon, 1500);
      const tmpUserLat = state.userLat, tmpUserLon = state.userLon;
      state.userLat = lat; state.userLon = lon;
      const results = buildResults(elements, [cat]);
      state.userLat = tmpUserLat; state.userLon = tmpUserLon;
      if (results.length === 0) {
        els.suggestionSub.textContent = "No encontramos nada cerca hoy. Probá de nuevo más tarde.";
        return;
      }
      const pick = results[Math.floor(Math.random() * Math.min(results.length, 10))];
      saveCachedSuggestion(pick);
      showSuggestionResult(pick);
    } catch (err) {
      els.suggestionSub.textContent = "No pudimos obtener tu ubicación.";
    }
  });
}
function showSuggestionResult(p) {
  const def = CATEGORY_DEFS[p.category] || CATEGORY_DEFS.restaurante;
  els.suggestionSub.textContent = `${def.icon} ${p.name} — ${def.label}, a ${formatDistance(p.dist)} (${formatWalkTime(p.dist)}). Tocá para ver más.`;
  els.suggestionBtn.onclick = () => {
    if (state.userLat) p.dist = haversine(state.userLat, state.userLon, p.lat, p.lon);
    openPlaceSheet(p);
  };
}

// ---------- Compartir tarjeta de lugar como imagen ----------
async function sharePlaceCard(p) {
  try {
    const def = CATEGORY_DEFS[p.category] || CATEGORY_DEFS.restaurante;
    const canvas = document.createElement("canvas");
    const W = 800, H = 450;
    canvas.width = W; canvas.height = H;
    const ctx = canvas.getContext("2d");

    const grad = ctx.createLinearGradient(0, 0, W, H);
    grad.addColorStop(0, "#1A1916");
    grad.addColorStop(1, "#0E0D0B");
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, W, H);

    ctx.fillStyle = "#F5A623";
    ctx.font = "70px sans-serif";
    ctx.fillText(def.icon || "📍", 48, 130);

    ctx.fillStyle = "#EDE8DC";
    ctx.font = "bold 42px sans-serif";
    wrapText(ctx, p.name, 48, 210, W - 96, 50);

    ctx.fillStyle = "#928D83";
    ctx.font = "28px sans-serif";
    ctx.fillText(`${def.label} · ${formatDistance(p.dist)}${p.address ? " · " + p.address : ""}`, 48, 320);

    ctx.fillStyle = "#F5A623";
    ctx.font = "bold 24px sans-serif";
    ctx.fillText("📍 Encontrado con Cerca", 48, H - 36);

    const blob = await new Promise((resolve) => canvas.toBlob(resolve, "image/png"));
    if (!blob) throw new Error("no-blob");
    const file = new File([blob], "lugar.png", { type: "image/png" });

    if (navigator.share && navigator.canShare && navigator.canShare({ files: [file] })) {
      await navigator.share({ title: p.name, files: [file] });
      return;
    }

    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${p.name.replace(/[^a-z0-9]+/gi, "_")}.png`;
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 3000);
    showToast("Tarjeta descargada 🖼️");
  } catch (err) {
    console.error(err);
    showToast("No pudimos generar la tarjeta");
  }
}
function wrapText(ctx, text, x, y, maxWidth, lineHeight) {
  const words = text.split(" ");
  let line = "";
  let curY = y;
  for (const word of words) {
    const test = line + word + " ";
    if (ctx.measureText(test).width > maxWidth && line) {
      ctx.fillText(line, x, curY);
      line = word + " ";
      curY += lineHeight;
    } else {
      line = test;
    }
  }
  ctx.fillText(line, x, curY);
}

// ---------- Historial de búsquedas ----------
function loadHistory() {
  try {
    const raw = localStorage.getItem(HISTORY_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch (e) {
    return [];
  }
}

function saveHistoryList(list) {
  try {
    localStorage.setItem(HISTORY_KEY, JSON.stringify(list));
  } catch (e) {
    console.warn("No se pudo guardar el historial", e);
  }
}

function addHistoryEntry(entry) {
  state.history.unshift(entry);
  if (state.history.length > HISTORY_LIMIT) {
    state.history = state.history.slice(0, HISTORY_LIMIT);
  }
  saveHistoryList(state.history);
  updateHistoryBadge();
  if (state.activeTab === "busquedas") renderHistory();
}

function clearHistory() {
  state.history = [];
  saveHistoryList(state.history);
  updateHistoryBadge();
  renderHistory();
}

function updateHistoryBadge() {
  const n = state.history.length;
  els.historyBadge.hidden = n === 0;
  els.historyBadge.textContent = n > 99 ? "99+" : String(n);
}

// ---------- Precarga: mostrar la última búsqueda apenas se abre la app ----------
// Así el usuario ve algo apenas entra a "Búsquedas", en vez de una pantalla vacía
// esperando que toque "Buscar cerca mío". No pega a la red: usa lo que ya
// habíamos guardado la última vez que buscamos con éxito.
function preloadLastResults() {
  if (state.results.length > 0) return; // ya hay una búsqueda real cargada
  const cached = loadLastResult();
  if (!cached || !cached.elements || !cached.elements.length) return;

  state.userLat = cached.lat;
  state.userLon = cached.lon;
  state.results = buildResults(cached.elements, cached.cats);
  if (state.results.length === 0) return;

  state.mapCatFilter = new Set(cached.cats);
  state.lastQuery = { cats: cached.cats, radius: cached.radius };
  state.renderedCount = RESULTS_PAGE_SIZE;
  renderResults();

  if (els.busquedasIntro) els.busquedasIntro.hidden = true;
  els.resultsStatus.textContent = `Resultados de ${formatRelativeTime(cached.ts)} · no están actualizados`;
  els.refreshResultsBtn.hidden = false;
}

function renderHistory() {
  if (state.history.length === 0) {
    els.historyList.innerHTML = `<div class="empty-history">Todavía no hiciste ninguna búsqueda.<br>Buscá lugares desde Inicio y van a aparecer acá.</div>`;
    return;
  }

  els.historyList.innerHTML = state.history
    .map((entry, idx) => {
      const catList = entry.cats && entry.cats.length ? entry.cats : Object.keys(CATEGORY_DEFS);
      const icons = catList
        .slice(0, 4)
        .map((c) => (CATEGORY_DEFS[c] ? CATEGORY_DEFS[c].icon : ""))
        .join(" ");
      const labels = catList.map((c) => (CATEGORY_DEFS[c] ? CATEGORY_DEFS[c].label : c)).join(", ");
      return `
        <button class="history-card" data-idx="${idx}">
          <span class="history-icons">${icons || "🔎"}</span>
          <span class="history-info">
            <p class="history-title">${escapeHtml(labels || "Todas las categorías")}</p>
            <span class="history-meta">
              <span>${formatDistance(entry.radius, true)}</span>
              <span>${entry.count} resultado${entry.count === 1 ? "" : "s"}</span>
            </span>
          </span>
          <span class="history-time">${formatRelativeTime(entry.ts)}</span>
          <span class="history-replay" aria-hidden="true">↻</span>
        </button>
      `;
    })
    .join("");
}

els.historyList.addEventListener("click", (e) => {
  const card = e.target.closest(".history-card");
  if (!card) return;
  const entry = state.history[Number(card.dataset.idx)];
  if (!entry) return;
  runSearch({ cats: entry.cats, radius: entry.radius });
});

function formatRelativeTime(ts) {
  const diffMs = Date.now() - ts;
  const min = Math.floor(diffMs / 60000);
  if (min < 1) return "ahora";
  if (min < 60) return `hace ${min} min`;
  const hs = Math.floor(min / 60);
  if (hs < 24) return `hace ${hs} h`;
  const days = Math.floor(hs / 24);
  if (days < 7) return `hace ${days} d`;
  return new Date(ts).toLocaleDateString("es-AR", { day: "2-digit", month: "2-digit" });
}

// ---------- Menú ----------
els.menuClearHistory.addEventListener("click", () => {
  if (state.history.length === 0) {
    showToast("El historial ya está vacío");
    return;
  }
  if (confirm("¿Borrar todo tu historial de búsqueda? Esta acción no se puede deshacer.")) {
    clearHistory();
    showToast("Historial borrado");
  }
});

if (els.menuRestoreReported) {
  els.menuRestoreReported.addEventListener("click", () => {
    if (state.hiddenPlaces.size === 0) {
      showToast("No tenés lugares reportados");
      return;
    }
    if (confirm(`¿Restaurar ${state.hiddenPlaces.size} lugar${state.hiddenPlaces.size === 1 ? "" : "es"} que ocultaste?`)) {
      state.hiddenPlaces.clear();
      saveHiddenPlaces();
      showToast("Restaurados. Volvé a buscar para verlos");
    }
  });
}

if (els.menuEraseAll) {
  els.menuEraseAll.addEventListener("click", () => {
    const sure = confirm(
      "¿Borrar todos tus datos guardados en este dispositivo?\n\nSe van a eliminar tus favoritos, notas, historial, combos, búsquedas guardadas, el auto guardado y tus preferencias. Nada de esto se manda a ningún servidor — vive solo en este dispositivo — pero esta acción no se puede deshacer."
    );
    if (!sure) return;
    try {
      ALL_STORAGE_KEYS.forEach((k) => localStorage.removeItem(k));
    } catch (e) {}
    showToast("Listo, borramos todos tus datos");
    setTimeout(() => window.location.reload(), 700);
  });
}

els.menuShareWhatsapp.addEventListener("click", shareWhatsApp);

if (els.menuCopyLink) {
  els.menuCopyLink.addEventListener("click", async () => {
    try {
      await navigator.clipboard.writeText(window.location.href);
      showToast("Link copiado 🔗");
    } catch (err) {
      showToast("No pudimos copiar el link");
    }
  });
}

// ---------- Exportar / importar favoritos y notas ----------
if (els.menuExportFavorites) {
  els.menuExportFavorites.addEventListener("click", () => {
    if (state.favorites.length === 0) {
      showToast("Todavía no tenés favoritos para exportar");
      return;
    }
    const payload = {
      app: "cerca",
      version: 1,
      exportedAt: new Date().toISOString(),
      favorites: state.favorites,
      notes: state.notes,
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `cerca-favoritos-${todayKey()}.json`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 2000);
    showToast("Favoritos exportados ⬇️");
  });
}

if (els.menuImportFavorites && els.importFavoritesInput) {
  els.menuImportFavorites.addEventListener("click", () => els.importFavoritesInput.click());

  els.importFavoritesInput.addEventListener("change", async () => {
    const file = els.importFavoritesInput.files && els.importFavoritesInput.files[0];
    els.importFavoritesInput.value = "";
    if (!file) return;
    try {
      const text = await file.text();
      const data = JSON.parse(text);
      const incomingFavs = Array.isArray(data.favorites) ? data.favorites : [];
      const incomingNotes = data.notes && typeof data.notes === "object" ? data.notes : {};
      if (incomingFavs.length === 0) {
        showToast("El archivo no tiene favoritos válidos");
        return;
      }
      let added = 0;
      incomingFavs.forEach((f) => {
        if (!f || f.id == null) return;
        if (state.favorites.some((existing) => String(existing.id) === String(f.id))) return;
        state.favorites.push(f);
        added++;
      });
      Object.keys(incomingNotes).forEach((id) => {
        if (!state.notes[id]) state.notes[id] = incomingNotes[id];
      });
      saveFavoritesList();
      saveNotesMap();
      updateFavBadge();
      if (state.activeTab === "favoritos") renderFavorites();
      showToast(`Importados ${added} favoritos nuevos 📥`);
    } catch (err) {
      showToast("No pudimos leer ese archivo. ¿Es un JSON exportado desde Cerca?");
    }
  });
}

function buildShareText() {
  const appUrl = window.location.href;
  if (state.results.length > 0) {
    const top = state.results.slice(0, 5);
    const lines = top.map((p) => {
      const def = CATEGORY_DEFS[p.category] || CATEGORY_DEFS.restaurante;
      const mapsUrl = `https://www.google.com/maps/search/?api=1&query=${p.lat},${p.lon}`;
      return `${def.icon} ${p.name} — ${formatDistance(p.dist)}\n${mapsUrl}`;
    });
    return `Encontré estos lugares cerca con Cerca 📍:\n\n${lines.join("\n\n")}\n\nBuscá vos también 👉 ${appUrl}`;
  }
  return `Mirá esta app para encontrar bares, cafés, parrillas y más cerca tuyo 📍\n${appUrl}`;
}

async function shareWhatsApp() {
  const appUrl = window.location.href;
  const text = buildShareText();

  // 1) Intento con Web Share API nativo: permite adjuntar la imagen de la app
  //    junto con el texto y elegir WhatsApp desde el selector del sistema.
  if (navigator.share) {
    try {
      let file = null;
      try {
        const resp = await fetch("icons/icon-512.png");
        const blob = await resp.blob();
        const candidate = new File([blob], "cerca.png", { type: blob.type || "image/png" });
        if (navigator.canShare && navigator.canShare({ files: [candidate] })) {
          file = candidate;
        }
      } catch (imgErr) {
        console.warn("No se pudo adjuntar la imagen", imgErr);
      }

      const shareData = file
        ? { title: "Cerca", text, files: [file] }
        : { title: "Cerca", text, url: appUrl };

      await navigator.share(shareData);
      return;
    } catch (err) {
      if (err && err.name === "AbortError") return; // el usuario canceló, no hacer fallback
    }
  }

  // 2) Fallback: link directo a WhatsApp Web/app (solo texto, sin imagen —
  //    wa.me no admite adjuntar archivos, es una limitación de WhatsApp).
  const url = `https://wa.me/?text=${encodeURIComponent(text)}`;
  window.open(url, "_blank", "noopener");
}

// ---------- Modo oscuro ----------
function loadDarkPreference() {
  const v = localStorage.getItem(DARK_KEY);
  if (v !== null) return v === "1"; // el usuario eligió manualmente → respetamos
  // Primera vez: seguimos la preferencia del sistema operativo
  if (window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches) return true;
  if (window.matchMedia && window.matchMedia("(prefers-color-scheme: light)").matches) return false;
  return true; // sin dato del sistema → oscuro por defecto
}

// Listener para cambios en tiempo real del tema del sistema
// (ej: el usuario cambia de claro a oscuro en el celular)
if (window.matchMedia) {
  window.matchMedia("(prefers-color-scheme: dark)").addEventListener("change", (e) => {
    // Solo reaccionamos si el usuario no eligió manualmente
    if (localStorage.getItem(DARK_KEY) === null) {
      setDarkMode(e.matches);
    }
  });
}

function setDarkMode(on) {
  document.body.classList.toggle("dark", on);
  els.darkModeToggle.classList.toggle("on", on);
  els.menuDarkMode.setAttribute("aria-checked", String(on));
  try {
    localStorage.setItem(DARK_KEY, on ? "1" : "0");
  } catch (e) {}
}

els.menuDarkMode.addEventListener("click", () => {
  const isOn = !document.body.classList.contains("dark");
  setDarkMode(isOn);
  // Marcar que el usuario eligió manualmente (ya lo hace setDarkMode vía localStorage)
});

// ---------- Acerca de (modal) ----------
function trapModalKeydown(e, overlay, closeFn) {
  if (e.key === "Escape") {
    e.stopPropagation();
    closeFn();
    return;
  }
  if (e.key !== "Tab") return;
  const focusables = Array.prototype.slice.call(
    overlay.querySelectorAll('a[href], button:not([disabled]), textarea, input, [tabindex]:not([tabindex="-1"])')
  );
  if (!focusables.length) return;
  const first = focusables[0];
  const last = focusables[focusables.length - 1];
  if (e.shiftKey && document.activeElement === first) {
    e.preventDefault();
    last.focus();
  } else if (!e.shiftKey && document.activeElement === last) {
    e.preventDefault();
    first.focus();
  }
}
let aboutTriggerEl = null;
els.menuAbout.addEventListener("click", () => {
  aboutTriggerEl = document.activeElement;
  els.aboutOverlay.hidden = false;
  requestAnimationFrame(() => els.aboutClose.focus());
});
function closeAboutOverlay() {
  els.aboutOverlay.hidden = true;
  if (aboutTriggerEl && typeof aboutTriggerEl.focus === "function") aboutTriggerEl.focus();
  aboutTriggerEl = null;
}
els.aboutClose.addEventListener("click", closeAboutOverlay);
els.aboutOverlay.addEventListener("click", (e) => {
  if (e.target === els.aboutOverlay) closeAboutOverlay();
});
els.aboutOverlay.addEventListener("keydown", (e) => trapModalKeydown(e, els.aboutOverlay, closeAboutOverlay));

// ---------- Toast ----------
let toastTimer = null;
function showToast(msg) {
  els.toast.textContent = msg;
  els.toast.hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => {
    els.toast.hidden = true;
  }, 2200);
}

// ---------- Prompt de instalación propio (beforeinstallprompt) ----------
// En vez de esperar a que el usuario busque "Instalar app" en el menú del
// navegador, interceptamos el evento y mostramos nuestro propio banner en
// el momento justo: después de la primera búsqueda exitosa.
let deferredInstallPrompt = null;
let installBannerShownThisSession = false;

function isRunningStandalone() {
  return (
    window.matchMedia("(display-mode: standalone)").matches ||
    window.navigator.standalone === true
  );
}

window.addEventListener("beforeinstallprompt", (e) => {
  e.preventDefault();
  deferredInstallPrompt = e;
});

function maybeShowInstallBanner() {
  if (!els.installBanner || !deferredInstallPrompt) return;
  if (installBannerShownThisSession) return;
  if (isRunningStandalone()) return;
  try {
    if (localStorage.getItem(INSTALL_DISMISSED_KEY)) return;
  } catch (e) {}
  installBannerShownThisSession = true;
  els.installBanner.hidden = false;
}

function hideInstallBanner() {
  if (els.installBanner) els.installBanner.hidden = true;
}

if (els.installBannerBtn) {
  els.installBannerBtn.addEventListener("click", async () => {
    hideInstallBanner();
    if (!deferredInstallPrompt) return;
    deferredInstallPrompt.prompt();
    try {
      const choice = await deferredInstallPrompt.userChoice;
      if (choice.outcome !== "accepted") {
        try { localStorage.setItem(INSTALL_DISMISSED_KEY, "1"); } catch (e) {}
      }
    } catch (e) {}
    deferredInstallPrompt = null;
  });
}
if (els.installBannerClose) {
  els.installBannerClose.addEventListener("click", () => {
    hideInstallBanner();
    try { localStorage.setItem(INSTALL_DISMISSED_KEY, "1"); } catch (e) {}
  });
}
window.addEventListener("appinstalled", () => {
  deferredInstallPrompt = null;
  hideInstallBanner();
  try { localStorage.setItem(INSTALL_DISMISSED_KEY, "1"); } catch (e) {}
});

// ---------- Búsqueda por dirección (Nominatim autocomplete) ----------
const elAddrInput = document.getElementById("addressInput");
const elAddrSuggestions = document.getElementById("addressSuggestions");
const elAddrClear = document.getElementById("addressClearBtn");

// Estado de búsqueda por dirección
const addrState = { lat: null, lon: null, label: "" };
let addrTimer = null;
let addrAbort = null;

if (elAddrInput) {
  elAddrInput.addEventListener("input", () => {
    const q = elAddrInput.value.trim();
    elAddrClear.hidden = !q;

    // Si borraron todo, volvemos a usar GPS
    if (!q) {
      addrState.lat = null;
      addrState.lon = null;
      addrState.label = "";
      elAddrSuggestions.hidden = true;
      return;
    }

    clearTimeout(addrTimer);
    addrTimer = setTimeout(() => fetchAddressSuggestions(q), 350);
  });

  elAddrInput.addEventListener("keydown", (e) => {
    if (e.key === "Escape") {
      elAddrSuggestions.hidden = true;
      elAddrInput.blur();
    }
  });
}

if (elAddrClear) {
  elAddrClear.addEventListener("click", () => {
    elAddrInput.value = "";
    elAddrClear.hidden = true;
    addrState.lat = null;
    addrState.lon = null;
    addrState.label = "";
    elAddrSuggestions.hidden = true;
    elAddrInput.focus();
  });
}

async function fetchAddressSuggestions(q) {
  if (addrAbort) addrAbort.abort();
  addrAbort = new AbortController();
  try {
    const url = `https://nominatim.openstreetmap.org/search?format=jsonv2&q=${encodeURIComponent(q)}&limit=5&countrycodes=ar&addressdetails=1&accept-language=es`;
    const res = await fetch(url, {
      headers: { "Accept-Language": "es" },
      signal: addrAbort.signal,
    });
    if (!res.ok) return;
    const data = await res.json();
    renderAddressSuggestions(data);
  } catch (e) {
    if (e.name !== "AbortError") console.warn("Nominatim error", e);
  }
}

function renderAddressSuggestions(results) {
  if (!results || results.length === 0) {
    elAddrSuggestions.hidden = true;
    return;
  }
  elAddrSuggestions.hidden = false;
  elAddrSuggestions.innerHTML = results
    .map((r, i) => {
      const display = r.display_name.split(",").slice(0, 3).join(", ");
      return `<button class="addr-suggestion" type="button" data-lat="${r.lat}" data-lon="${r.lon}" data-label="${encodeURIComponent(display)}">${escapeHtml(display)}</button>`;
    })
    .join("");
}

if (elAddrSuggestions) {
  elAddrSuggestions.addEventListener("click", (e) => {
    const btn = e.target.closest(".addr-suggestion");
    if (!btn) return;
    const lat = parseFloat(btn.dataset.lat);
    const lon = parseFloat(btn.dataset.lon);
    const label = decodeURIComponent(btn.dataset.label);
    addrState.lat = lat;
    addrState.lon = lon;
    addrState.label = label;
    elAddrInput.value = label;
    elAddrClear.hidden = false;
    elAddrSuggestions.hidden = true;
    elAddrInput.blur();
    // Lanzar búsqueda automáticamente al elegir una sugerencia
    runSearchFromAddress(lat, lon);
  });
}

// Cierra sugerencias al hacer click afuera
document.addEventListener("click", (e) => {
  if (elAddrSuggestions && !elAddrSuggestions.contains(e.target) && e.target !== elAddrInput) {
    elAddrSuggestions.hidden = true;
  }
});

async function runSearchFromAddress(lat, lon) {
  setStatus("");
  els.searchBtn.disabled = true;
  els.searchBtn.classList.add("loading");
  els.searchBtnLabel.textContent = "Buscando lugares…";

  state.userLat = lat;
  state.userLon = lon;

  const cats = state.selected.size > 0 ? [...state.selected] : Object.keys(CATEGORY_DEFS);
  state.lastQuery = { cats, radius: state.radius };
  state.lastSearchWasCache = false;
  state.lastSearchWasOffline = false;

  try {
    showResultsSkeleton();
    setStatus("Consultando OpenStreetMap…");
    switchTab("busquedas");
    const cacheKey = zoneCacheKey(lat, lon, state.radius, cats);
    const cached = getZoneCacheEntry(cacheKey);
    let elements;
    if (cached) {
      elements = cached.elements;
      state.lastSearchWasCache = true;
    } else {
      elements = await queryOverpass(cats, lat, lon, state.radius);
      setZoneCacheEntry(cacheKey, elements);
      saveLastResult({ cats, radius: state.radius, lat, lon, elements });
    }
    state.results = buildResults(elements, cats);
    state.mapCatFilter = new Set(cats);
    state.renderedCount = RESULTS_PAGE_SIZE;
    if (els.searchText) els.searchText.value = "";
    state.searchText = "";
    renderResults();
    if (state.lastSearchWasCache) {
      setStatus("Resultados desde caché", "cached");
      els.refreshResultsBtn.hidden = false;
    } else if (state.results.length > 0) {
      showFoundStatus(state.results.length);
      els.refreshResultsBtn.hidden = true;
      maybeShowInstallBanner();
    } else {
      setStatus("");
    }
    addHistoryEntry({ ts: Date.now(), cats, radius: state.radius, count: state.results.length, lat, lon });
  } catch (err) {
    console.error(err);
    setStatus(errorMessage(err), "error");
  } finally {
    els.searchBtn.disabled = false;
    els.searchBtn.classList.remove("loading");
    els.searchBtnLabel.textContent = "Buscar cerca mío";
  }
}

// ---------- Buscar en esta zona del mapa ----------
const elSearchHereBtn = document.getElementById("searchHereBtn");
let searchHereDebounce = null;

function setupSearchHere() {
  if (!state.map || !elSearchHereBtn) return;
  state.map.on("moveend", () => {
    // Solo mostramos el botón si el mapa se movió manualmente (no por flyToBounds automático)
    if (state._mapAutoMove) return;
    elSearchHereBtn.hidden = false;
  });
  state.map.on("movestart", () => {
    // Si el movimiento lo inicia el código (flyTo/flyToBounds), lo marcamos
    // Leaflet no distingue programático de usuario, pero podemos usar una bandera
  });
  elSearchHereBtn.addEventListener("click", () => {
    const center = state.map.getCenter();
    elSearchHereBtn.hidden = true;
    runSearchFromAddress(center.lat, center.lng);
  });
}

// Hook para marcar movimientos programáticos del mapa
const _origFlyTo = L && L.Map && L.Map.prototype.flyTo;
// El setup se llama después de que el mapa se inicializa
const _origInitMap = initMapIfNeeded;
function initMapIfNeeded() {
  _origInitMap();
  if (state.map && elSearchHereBtn && !state._searchHereSetup) {
    state._searchHereSetup = true;
    setupSearchHere();
  }
}

// ---------- Vista dedicada: Mapa (posición actual + favoritos, sin pasar por Búsquedas) ----------
function initMapaMapIfNeeded() {
  if (state.mapaMap) return;
  if (typeof L === "undefined") {
    console.warn("Leaflet no está disponible; el mapa queda deshabilitado.");
    return;
  }
  state.mapaMap = L.map("mapaMap", { zoomControl: true });
  L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
    attribution: "&copy; OpenStreetMap contributors",
    maxZoom: 19,
  }).addTo(state.mapaMap);
  state.mapaMarkersLayer = L.layerGroup().addTo(state.mapaMap);
  state.mapaMap.setView(
    state.userLat != null ? [state.userLat, state.userLon] : [-34.6, -58.4],
    state.userLat != null ? 15 : 4
  );
}

async function renderMapaTab() {
  try {
    initMapaMapIfNeeded();
  } catch (err) {
    console.warn("No se pudo inicializar el mapa", err);
  }
  if (!state.mapaMap) return;
  setTimeout(() => state.mapaMap && state.mapaMap.invalidateSize(), 50);

  if (state.userLat == null) {
    els.mapaStatus.hidden = false;
    els.mapaStatus.textContent = "Ubicándote…";
    try {
      const pos = await getPosition();
      state.userLat = pos.coords.latitude;
      state.userLon = pos.coords.longitude;
      els.mapaStatus.hidden = true;
    } catch (err) {
      els.mapaStatus.textContent = state.favorites.length
        ? "No pudimos obtener tu ubicación. Te mostramos igual tus favoritos."
        : "No pudimos obtener tu ubicación, y todavía no tenés favoritos guardados.";
    }
  } else {
    els.mapaStatus.hidden = true;
  }
  updateMapaMarkers();
}

function updateMapaMarkers() {
  if (!state.mapaMap || !state.mapaMarkersLayer) return;
  state.mapaMarkersLayer.clearLayers();
  const bounds = [];

  if (state.userLat != null) {
    const userIcon = L.divIcon({
      className: "",
      html: `<div style="width:16px;height:16px;border-radius:50%;background:#0A84FF;border:2px solid #fff;box-shadow:0 0 0 4px rgba(10,132,255,0.25);"></div>`,
      iconSize: [16, 16],
      iconAnchor: [8, 8],
    });
    L.marker([state.userLat, state.userLon], { icon: userIcon })
      .addTo(state.mapaMarkersLayer)
      .bindPopup("<strong>Estás acá</strong>");
    bounds.push([state.userLat, state.userLon]);
  }

  if (state.car) {
    const carIcon = L.divIcon({
      className: "",
      html: `<div style="font-size:18px;filter:drop-shadow(0 1px 2px rgba(0,0,0,0.6));">🚗</div>`,
      iconSize: [22, 22],
      iconAnchor: [11, 11],
    });
    L.marker([state.car.lat, state.car.lon], { icon: carIcon })
      .addTo(state.mapaMarkersLayer)
      .bindPopup("<strong>Tu auto</strong>");
    bounds.push([state.car.lat, state.car.lon]);
  }

  state.favorites.forEach((p) => {
    const def = CATEGORY_DEFS[p.category] || CATEGORY_DEFS.restaurante;
    const icon = L.divIcon({
      className: "",
      html: `<div class="marker-enter" style="font-size:18px;line-height:1;filter:drop-shadow(0 1px 2px rgba(0,0,0,0.6));">${def.icon}</div>`,
      iconSize: [24, 24],
      iconAnchor: [12, 12],
    });
    L.marker([p.lat, p.lon], { icon })
      .addTo(state.mapaMarkersLayer)
      .bindPopup(`<strong>${escapeHtml(p.name)}</strong><br>${def.label} · ⭐ favorito`);
    bounds.push([p.lat, p.lon]);
  });

  if (bounds.length > 1) {
    state.mapaMap.flyToBounds(bounds, { padding: [30, 30], maxZoom: 16, duration: 0.7 });
  } else if (bounds.length === 1) {
    state.mapaMap.flyTo(bounds[0], 15, { duration: 0.7 });
  }
}

// ---------- Init ----------
state.history = loadHistory();
updateHistoryBadge();
setDarkMode(loadDarkPreference());

state.favorites = loadFavorites();
updateFavBadge();

state.notes = loadNotes();

state.savedSearches = loadSavedSearches();

state.settings = loadSettings();
applyAccent(state.settings.accent);
if (els.sortSelect) els.sortSelect.value = state.settings.sortBy || "dist";
if (els.openNowToggle) {
  els.openNowToggle.classList.toggle("on", !!state.settings.openNowOnly);
  els.openNowToggle.setAttribute("aria-pressed", String(!!state.settings.openNowOnly));
}
if (els.wheelchairToggle) {
  els.wheelchairToggle.classList.toggle("on", !!state.settings.wheelchairOnly);
  els.wheelchairToggle.setAttribute("aria-pressed", String(!!state.settings.wheelchairOnly));
}

state.hiddenPlaces = loadHiddenPlaces();

state.combos = loadCombos();
renderCombos();

state.dataSaver = computeDataSaver();
(function watchDataSaver() {
  const conn = getNetworkInfo();
  if (!conn || !conn.addEventListener) return;
  conn.addEventListener("change", () => {
    const was = state.dataSaver;
    state.dataSaver = computeDataSaver();
    if (was !== state.dataSaver) {
      if (state.dataSaver) showToast("Ahorro de datos activado: no cargamos más fotos");
      if (state.results && state.results.length) renderResults();
      if (state.activeTab === "favoritos") renderFavorites();
    }
  });
})();

if (state.settings.defaultRadius) {
  state.radius = state.settings.defaultRadius;
  els.radius.value = state.radius;
  els.radiusValue.textContent = formatDistance(state.radius, true);
}
const firstUseCats = ["bar", "cafe", "restaurante"];
if (state.settings.defaultCats && state.settings.defaultCats.length) {
  state.selected = new Set(state.settings.defaultCats);
} else {
  // Primera vez: preseleccionamos las categorías más usadas
  state.selected = new Set(firstUseCats);
}
document.querySelectorAll(".cat-card").forEach((card) => {
  const isSel = state.selected.has(card.dataset.cat);
  card.classList.toggle("selected", isSel);
  card.setAttribute("aria-pressed", String(isSel));
});
renderCombos();

state.car = loadCar();
updateCarMenuItem();

requestAnimationFrame(() => {
  const activeDock = els.dock.querySelector(".dock-item.active");
  slideGlassThumb(els.dock, els.dockThumb, activeDock);
});

const cachedSuggestion = loadCachedSuggestion();
if (cachedSuggestion) showSuggestionResult(cachedSuggestion);

preloadLastResults();

// ---------- Onboarding (primera vez) ----------
try {
  if (!localStorage.getItem(ONBOARDING_KEY)) {
    els.onboardingOverlay.hidden = false;
    requestAnimationFrame(() => els.onboardingClose.focus());
  }
} catch (e) {}

function closeOnboarding() {
  els.onboardingOverlay.hidden = true;
  try { localStorage.setItem(ONBOARDING_KEY, "1"); } catch (e) {}
}
els.onboardingClose.addEventListener("click", closeOnboarding);
els.onboardingOverlay.addEventListener("keydown", (e) => trapModalKeydown(e, els.onboardingOverlay, closeOnboarding));

// ---------- Service worker ----------
if ("serviceWorker" in navigator) {
  window.addEventListener("load", () => {
    navigator.serviceWorker.register("sw.js").catch((e) => console.warn("SW registration failed", e));
  });
  // Cuando un SW nuevo toma el control (deploy nuevo en GitHub Pages),
  // recargamos una sola vez para que se vea la versión al día.
  let swReloaded = false;
  navigator.serviceWorker.addEventListener("controllerchange", () => {
    if (swReloaded) return;
    swReloaded = true;
    window.location.reload();
  });
}

// ---------- Warm-up silencioso de GPS ----------
// Si el usuario ya nos dio permiso de ubicación antes, pedimos la posición
// apenas abre la app (sin mostrar ningún prompt) para que "Buscar cerca mío"
// responda más rápido cuando la toque.
if ("permissions" in navigator && "geolocation" in navigator) {
  navigator.permissions
    .query({ name: "geolocation" })
    .then((status) => {
      if (status.state === "granted") {
        navigator.geolocation.getCurrentPosition(
          (pos) => {
            state.userLat = pos.coords.latitude;
            state.userLon = pos.coords.longitude;
            if (state.mapaMap) {
              els.mapaStatus.hidden = true;
              updateMapaMarkers();
            }
          },
          () => {},
          { enableHighAccuracy: false, timeout: 8000, maximumAge: 60000 }
        );
      }
    })
    .catch(() => {});
}

// ---------- Atajos del manifest (shortcuts: mantener presionado el ícono) ----------
// index.html?action=search -> dispara "Buscar cerca mío" apenas abre
// index.html?action=car    -> abre directo la ficha de "Cerca del auto"
(function handleShortcutAction() {
  try {
    const params = new URLSearchParams(window.location.search);
    const action = params.get("action");
    if (!action) return;
    window.history.replaceState({}, "", window.location.pathname);
    requestAnimationFrame(() => {
      if (action === "search" && els.searchBtn) {
        els.searchBtn.click();
      } else if (action === "car" && els.menuCar) {
        switchTab("menu");
        els.menuCar.click();
      }
    });
  } catch (e) { /* noop */ }
})();
